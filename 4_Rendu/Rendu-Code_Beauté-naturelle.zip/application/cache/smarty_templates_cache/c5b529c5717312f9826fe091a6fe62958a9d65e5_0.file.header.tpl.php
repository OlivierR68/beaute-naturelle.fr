<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-16 20:59:56
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e49ad4caf1ff1_28385659',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c5b529c5717312f9826fe091a6fe62958a9d65e5' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\templates\\header.tpl',
      1 => 1581886795,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./admin-top-bar.tpl' => 1,
    'file:./slider.tpl' => 1,
  ),
),false)) {
function content_5e49ad4caf1ff1_28385659 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>

<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Accueil - Beauté Naturelle - Cosmétiques & soins Bio</title>
    <meta name="description"
        content="Magasin de coméstiques et institut de soins bio et naturelle, situé au dans la vielle ville de colmar, vénez découvrir notre sélection de produits et soins bio" />
    <meta name="author" content="Olivier Ravinasaga" />

    <meta name=”robots” content=”index, follow”>
    <meta name="format-detection" content="telephone=no">

    <link href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700|Lora&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url("assets/css/styles.css");?>
">
    <link rel="stylesheet" href="<?php echo base_url('assets/vendor/lightbox/css/lightbox.min.css');?>
">

    <link rel="shortcut icon" href="<?php echo base_url("assets/favicon.ico");?>
" type="image/x-icon">
    <link rel="icon" href="<?php echo base_url('assets/favicon.png');?>
" type="image/png">
    <link rel="icon" sizes="32x32" href="<?php echo base_url("assets/favicon-32.png");?>
" type="image/png">
    <link rel="icon" sizes="64x64" href="<?php echo base_url("assets/favicon-64.png");?>
" type="image/png">
    <link rel="icon" sizes="96x96" href="<?php echo base_url("assets/favicon-96.png");?>
" type="image/png">

</head>
<body>
    <!-- Back to top button -->
    <a id="b2top-button"></a>



    <header>
        <?php if (isset($_SESSION['login'])) {?>

            <?php if ($_SESSION['level'] > 1) {?>

                <?php $_smarty_tpl->_subTemplateRender('file:./admin-top-bar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

            <?php }?>

        <?php }?>
        <!--TOP BAR USER -->

        <div class="bn_bg-color-1">
            <div
                class="container bn_top-bar d-flex align-items-center justify-content-center justify-content-md-between">
                <div class="bn_infos">
                    <a class="bn_infos-items" href="<?php echo site_url('pages/contact');?>
"><i
                                class="fas fa-phone"></i>01.23.45.67.89</a>

                    <a class="bn_infos-items" title="" href="<?php echo site_url('pages/contact');?>
"><i
                                class="fas fa-clock"></i>Actuellement : <?php echo the_morand_function();?>
</a>
                </div>

                <div class="bn_infos">

                    <?php if (isset($_SESSION['login'])) {?>
                        <a class="bn_infos-items" href="<?php echo site_url('users/profile');?>
"><i class="far fa-caret-square-down"></i>Bonjour <?php echo $_SESSION['first_name'];?>
</a>
                        <a class="bn_infos-items" href="<?php echo site_url('users/disconnect');?>
"><i class="fas fa-sign-out-alt"></i>Se Deconnecter</a>
                    <?php } else { ?>
                        <a class="bn_infos-items" href="<?php echo site_url('users/login');?>
"><i class="fas fa-sign-in-alt"></i> Se Connecter</a>
                        <a class="bn_infos-items" href="<?php echo site_url('users/register');?>
"><i class="fas fa-user-plus"></i> S'Inscrire</a>
                    <?php }?>


                </div>

            </div>
        </div>

        <!-- NAV -->

        <div class="bn_opacity-90 bn_bg-main sticky-top">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light">

                    <a class="navbar-brand mx-auto mx-lg-0" href="<?php echo site_url();?>
">
                        <!--TOP LOGO -->
                        <div class="bn_logo-top">
                            <img src="<?php echo base_url("assets/img/logo.svg");?>
" class="bn_logo-svg" alt="logo beauté naturelle">
                            <div class="bn_logg-text">

                                <span class="bn_logo-text-1">beauté naturelle</span>
                                <span class="bn_logo-text-2">cosmétiques & soins bio</span>

                            </div>
                        </div>
                    </a>

                    <!-- NAV MENU -->

                    <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse"
                        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-bars"></i>
                    </button>

                    <div class="collapse navbar-collapse bn_bg-main" id="navbarSupportedContent">
                        <ul class="navbar-nav  ml-auto">

                            <li class="nav-item mx-1 bn_nav-item bn_<?php echo active_page('slides/home');?>
">
                                <a class="nav-link bn_nav-link " href="<?php echo site_url();?>
">Accueil <span
                                        class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item mx-1 bn_nav-item <?php echo active_page('events','bn_active',1);?>
">
                                <a class="nav-link bn_nav-link" href="<?php echo site_url("events");?>
">Évènements</a>
                            </li>

                            <li class="nav-item mx-1 bn_nav-item dropdown <?php echo active_page('prestations','bn_active',1);?>
">
                                <a class="nav-link bn_nav-link dropdown-toggle" href="<?php echo site_url("prestations");?>
" id="navbarDropdown"
                                   role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Prestations
                                </a>
                                <div class="dropdown-menu bn_bg-main" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item <?php echo active_page('prestations/index','bn_active');?>
" href="<?php echo site_url('prestations');?>
">Présentation</a>
                                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['dropdown_menu']->value, 'dropdown_item');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['dropdown_item']->value) {
?>
                                        <a class="dropdown-item <?php if (isset($_smarty_tpl->tpl_vars['current_uri']->value) && $_smarty_tpl->tpl_vars['current_uri']->value == $_smarty_tpl->tpl_vars['dropdown_item']->value->getSlug()) {?>bn_active<?php }?> " href="<?php echo $_smarty_tpl->tpl_vars['dropdown_item']->value->getUrl();?>
"><?php echo $_smarty_tpl->tpl_vars['dropdown_item']->value->getTitle();?>
</a>
                                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                </div>
                            </li>

                            <li class="nav-item mx-1 bn_nav-item mx-1 bn_<?php echo active_page('pages/about');?>
">
                                <a class="nav-link bn_nav-link" href="<?php echo site_url('pages/about');?>
">L'Établissement </a>
                            </li>
                            <li class="nav-item mx-1 bn_nav-item <?php echo active_page('images','bn_active',1);?>
">
                                <a class="nav-link bn_nav-link" href="<?php echo site_url('images');?>
">Galerie</a>
                            </li>
                            <li class="nav-item mx-1 bn_nav-item bn_<?php echo active_page('pages/contact');?>
">
                                <a class="nav-link bn_nav-link" href="<?php echo site_url('pages/contact');?>
">Contact</a>
                            </li>
                        </ul>
                </nav>


            </div>
        </div>

    </header>

	<?php if (page_name() == 'home' && !empty($_smarty_tpl->tpl_vars['arrSlides']->value)) {?>

        <?php $_smarty_tpl->_subTemplateRender("file:./slider.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	<?php } else { ?>

	<div class="bn_img-top bn_decal-slider" style="background-image: url(<?php echo $_smarty_tpl->tpl_vars['headerImg']->value;?>
)"></div>

	<?php }?>

    <?php if (isset($_smarty_tpl->tpl_vars['menu_cat_list']->value)) {?>
        <div class="bn_bg-color-1">
            <div class="container bn_arianne bn_color-white bn_small-text text-center text-uppercase">
                <nav class="row no-gutters">

                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['menu_cat_list']->value, 'cat_obj');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['cat_obj']->value) {
?>
                        <a href="<?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getUrl();?>
" class="col-4 col-sm-3 col-lg py-2 bn_a-white <?php if ($_smarty_tpl->tpl_vars['current_uri']->value == $_smarty_tpl->tpl_vars['cat_obj']->value->getSlug()) {?>bn_active-presta<?php }?> text-nowrap">
                            <?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getTitle();?>

                        </a>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

                </nav>


            </div>
        </div>
    <?php }?>
    <!--------- Menu Rapide Prestations  -------->


	<div class="bn_block-title">
		<span><?php echo $_smarty_tpl->tpl_vars['preTITLE']->value;?>
</span>
		<h1><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
</h1>
		<div></div>
	</div>


<?php }
}
