<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-11 13:02:21
  from '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/back/dashboard.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e42a5ddb11211_27471586',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '648fddfede5d4771c30d86147f768427710c376e' => 
    array (
      0 => '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/back/dashboard.tpl',
      1 => 1581315281,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e42a5ddb11211_27471586 (Smarty_Internal_Template $_smarty_tpl) {
?><p>Dashboard à faire</p>
<?php }
}
