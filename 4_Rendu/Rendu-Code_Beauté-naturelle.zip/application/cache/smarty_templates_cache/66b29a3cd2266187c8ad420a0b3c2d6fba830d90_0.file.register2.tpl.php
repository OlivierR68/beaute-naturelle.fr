<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-06 07:22:33
  from 'C:\Users\disiitp10\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\register2.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e3bbeb93629c4_01697177',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '66b29a3cd2266187c8ad420a0b3c2d6fba830d90' => 
    array (
      0 => 'C:\\Users\\disiitp10\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\register2.tpl',
      1 => 1580973637,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e3bbeb93629c4_01697177 (Smarty_Internal_Template $_smarty_tpl) {
}
}
