<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 15:05:48
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\categoriesAdd.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e4808cc8b74b3_39559031',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '989d9dbd7626539043a713de4c68d8c6f85e8220' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\categoriesAdd.tpl',
      1 => 1581778798,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e4808cc8b74b3_39559031 (Smarty_Internal_Template $_smarty_tpl) {
?><form enctype="multipart/form-data" method="post">

    <div class="form-group">
        <label>Titre</label>
        <input type="text" name="title" class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getTitle();?>
" required>
    </div>

    <div class="form-group">
        <div>
            <label for="inputVisible">Visible au public :</label>
        </div>

        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="visible" id="inputVisible1" value="1" <?php if ($_smarty_tpl->tpl_vars['cat_obj']->value->getVisible() == 1) {?>checked<?php }?> required >
            <label class="form-check-label" for="inputVisible1">Oui</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="visible" id="inputVisible2" value="0" <?php if ($_smarty_tpl->tpl_vars['cat_obj']->value->getVisible() == 0) {?>checked<?php }?> required >
            <label class="form-check-label" for="inputVisible2">Non</label>
        </div>
    </div>

    <div class="form-group">
        <?php if ((!empty($_smarty_tpl->tpl_vars['cat_obj']->value->getHeader()))) {?>
            <div>
                <img src="<?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getHeaderUrl();?>
" alt="" class="w-50 py-4 border-light">
            </div>


            <label for="inputImg">Changer le Header :</label>
        <?php } else { ?>

            <label for="inputImg">Uploader un Header :</label>

        <?php }?>

        <input type="file" class="form-control-file" name="header" accept=".jpg, .jpeg, .png, .gif">
        <small class="form-text text-muted">Poids maximum : 2 mo <br>Dimensions conseillées : 1920x500 px</small>
    </div>


    <div class="form-group">
        <?php if ((!empty($_smarty_tpl->tpl_vars['cat_obj']->value->getImg()))) {?>
            <div>
                <img src="<?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getImgUrl();?>
" alt="" class="w-25 py-4 border-light">
            </div>


            <label for="inputImg">Changer l'image :</label>
        <?php } else { ?>

            <label for="inputImg">Uploader une image :</label>

        <?php }?>

        <input type="file" class="form-control-file" name="img" accept=".jpg, .jpeg, .png, .gif">
        <small class="form-text text-muted">Poids maximum : 2 mo <br>Dimensions conseillées : 500x400 px</small>
    </div>

    <div class="form-group">
        <label>Description</label>
        <textarea class="form-control" name="description" rows="3"><?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getDescription();?>
</textarea>
    </div>



    <div class="d-flex flex-wrap">
        <button type="submit" class="btn btn-primary d-block mr-1 mb-1"><?php echo $_smarty_tpl->tpl_vars['buttonSubmit']->value;?>
</button>
        <a href="<?php echo base_url('prestations/listPage_cat');?>
" class="btn btn-dark d-block mr-1 mb-1"><?php echo $_smarty_tpl->tpl_vars['buttonCancel']->value;?>
</a>

        <?php if (isset($_smarty_tpl->tpl_vars['next']->value)) {?>
            <a href="<?php echo base_url('prestations/delete_cat/');
echo $_smarty_tpl->tpl_vars['cat_obj']->value->getId();?>
" class="btn btn-danger d-block mr-1 mb-1"
               data-href="<?php echo base_url('prestations/delete_cat/');
echo $_smarty_tpl->tpl_vars['cat_obj']->value->getId();?>
"
               data-toggle="modal" data-target="#confirm-delete">
                Supprimer
            </a>
        <?php }?>
    </div>

</form>

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Confirmer la suppression
            </div>
            <div class="modal-body font-weight-bold">
                <p>Voulez-vous vraiment supprimer la catégorie ?</p>
                <div class="bg-danger rounded p-2 text-white ">
                    <i class="fas fa-exclamation-triangle mr-1"></i> Supprimer la catégorie entrainera la suppression de
                    toutes les sous-catégories et prestations enfants.
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal">Annuler</button>
                <a class="btn btn-danger btn-ok text-white">Supprimer</a>
            </div>
        </div>
    </div>
</div><?php }
}
