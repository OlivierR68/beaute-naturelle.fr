<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 15:57:25
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\prestationsEdit.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e4814e5765bf4_81155438',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b1e4463f6d108cde178d4c560323900c6e7fcfe4' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\prestationsEdit.tpl',
      1 => 1581782214,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e4814e5765bf4_81155438 (Smarty_Internal_Template $_smarty_tpl) {
?>



<?php echo form_open();?>


<div class="form-group">
    <?php echo form_label('Catégorie | Sous-catégorie :','inputSubcat');?>

    <select  class="form-control "  name="sub_cat" id="inputSubcat">
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['sub_cat_list']->value, 'sub_cat');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['sub_cat']->value) {
?>
            <option <?php if ($_smarty_tpl->tpl_vars['presta_obj']->value->getSub_cat() == $_smarty_tpl->tpl_vars['sub_cat']->value['sub_cat_id']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['sub_cat']->value['sub_cat_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['sub_cat']->value['cat_title'];?>
 | <?php echo $_smarty_tpl->tpl_vars['sub_cat']->value['sub_cat_title'];?>
</option>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </select>
</div>

<div class="form-group">
    <?php echo form_label('Titre :','inputTitle');?>

    <?php echo form_input('title',$_smarty_tpl->tpl_vars['presta_obj']->value->getTitle(),'class="form-control" required id="inputTitle"');?>

</div>

<div class="form-group">
    <div>
        <label for="inputVisible">Visible au public :</label>
    </div>

    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="visible" id="inputVisible1" value="1" <?php if ($_smarty_tpl->tpl_vars['presta_obj']->value->getVisible() == 1) {?>checked<?php }?> required >
        <label class="form-check-label" for="inputVisible1">Oui</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="visible" id="inputVisible2" value="0" <?php if ($_smarty_tpl->tpl_vars['presta_obj']->value->getVisible() == 0) {?>checked<?php }?> required >
        <label class="form-check-label" for="inputVisible2">Non</label>
    </div>
</div>

<div class="form-group">
    <?php echo form_label('Ordre :','inputOrder');?>

    <input type="number" name="order" max="100" min="0" class="form-control" id="inputOrder" value="<?php echo $_smarty_tpl->tpl_vars['presta_obj']->value->getOrder();?>
">
</div>

<div class="form-group">
    <?php echo form_label('Description :','inputSubtext');?>

    <?php echo form_textarea('subtext',$_smarty_tpl->tpl_vars['presta_obj']->value->getSubtext(),'class="form-control" id="inputSubtext"');?>

</div>

<div class="form-group">
    <?php echo form_label('Durée :','inputDuration');?>

    <?php echo form_input('duration',$_smarty_tpl->tpl_vars['presta_obj']->value->getDuration(),'class="form-control" required id="inputDuration"');?>

</div>

<div class="form-group">
    <?php echo form_label('Prix :','inputPrice');?>

    <?php echo form_input('price',$_smarty_tpl->tpl_vars['presta_obj']->value->getPrice(),'class="form-control" required id="inputPrice"');?>

</div>


<div class="d-flex flex-wrap">
    <button type="submit" class="btn btn-primary d-block mr-1 mb-1"><?php echo $_smarty_tpl->tpl_vars['buttonSubmit']->value;?>
</button>
    <a href="<?php echo base_url('prestations/listPage');?>
" class="btn btn-dark d-block mr-1 mb-1"><?php echo $_smarty_tpl->tpl_vars['buttonCancel']->value;?>
</a>

    <?php if (isset($_smarty_tpl->tpl_vars['next']->value)) {?>
        <a href="<?php echo base_url('prestations/delete/');
echo $_smarty_tpl->tpl_vars['presta_obj']->value->getId();?>
" class="btn btn-danger d-block mr-1 mb-1"
           data-href="<?php echo base_url('prestations/delete/');
echo $_smarty_tpl->tpl_vars['presta_obj']->value->getId();?>
"
           data-toggle="modal" data-target="#confirm-delete">
            Supprimer
        </a>
        <a href="<?php echo base_url('prestations/addEdit');?>
?subcat=<?php echo $_smarty_tpl->tpl_vars['presta_obj']->value->getSub_cat();?>
" class="btn btn-secondary d-block mr-1 mb-1">Ajouter une nouvelle prestation</a>
        <a href="<?php echo base_url('prestations/addEdit');?>
?copy=<?php echo $_smarty_tpl->tpl_vars['presta_obj']->value->getId();?>
" class="btn btn-secondary d-block mr-1 mb-1">Copier vers une nouvelle prestation</a>
    <?php }?>
</div>


<?php echo form_close();?>



<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Confirmer la suppression
            </div>
            <div class="modal-body">
                Vous voulez vraiment supprimer la prestation <b class="bn_user"></b>?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal">Annuler</button>
                <a class="btn btn-danger btn-ok">Supprimer</a>
            </div>
        </div>
    </div>
</div><?php }
}
