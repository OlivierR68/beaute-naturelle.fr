<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-06 07:22:33
  from 'C:\Users\disiitp10\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\content.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e3bbeb93b67b1_99429770',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b70f912cea38e1e2534d1dbf9d94e21f53f7396b' => 
    array (
      0 => 'C:\\Users\\disiitp10\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\content.tpl',
      1 => 1580972995,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./templates/header.tpl' => 1,
    'file:./templates/footer.tpl' => 1,
  ),
),false)) {
function content_5e3bbeb93b67b1_99429770 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:./templates/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
echo $_smarty_tpl->tpl_vars['CONTENT']->value;?>

<?php $_smarty_tpl->_subTemplateRender("file:./templates/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php }
}
