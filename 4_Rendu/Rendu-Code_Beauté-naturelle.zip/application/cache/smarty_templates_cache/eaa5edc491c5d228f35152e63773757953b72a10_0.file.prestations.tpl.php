<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 10:12:34
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\prestations.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e47c412104739_83787277',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eaa5edc491c5d228f35152e63773757953b72a10' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\prestations.tpl',
      1 => 1581578781,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e47c412104739_83787277 (Smarty_Internal_Template $_smarty_tpl) {
?><main class="container bn_content">
	<section>

		<div class="row no-gutters">
			<div class="col-12 col-lg-6 d-flex align-items-center">
				<img src="<?php echo base_url('assets/img/massage-huiles-essentielles.jpg');?>
" class="img-fluid w-100"
					 alt="massage au huiles essentielles">
			</div>
			<div class="col-12 col-lg-6 p-4">

				<span class="bn_h2-pre">Institut bio</span>
				<h2>Notre Concept</h2>

				<p>
					Idéal pour se ressourcer à l’abri de la ville. Notre institut de 300 m2 dédié à la beauté, au
					bien-être, propice au calme et à la sérénité. Notre institut vous permet de prendre soin de vous
					le
					temps d’une parenthèse beauté. Une pause bien-être durant laquelle vous profiterez des soins
					visages et corps prodigués par nos 5 esthéticiennes professionnelles. Choisissez, parmi toutes
					les prestations dont vous souhaitez profiter ou faire profiter.</p>


			</div>
		</div>
	</section>


</main>
<div class="bn_gap-50"></div>



<div class="container">

	<div class="row">
		<!-- Foreach de catégorie ici -->
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arrCategories']->value, 'objCategory');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['objCategory']->value) {
?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['objCategory']->value->getUrl();?>
" style="background-image : url('<?php echo $_smarty_tpl->tpl_vars['objCategory']->value->getImgUrl();?>
')" class="col-6 col-lg-3 p-0 bn_presta-block d-flex ">

                <div class="<?php if ((isset($_smarty_tpl->tpl_vars['__smarty_foreach_objCategory']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_objCategory']->value['index'] : null)%2) {?>bn_bg-color-2<?php }?>"></div>
                <span>
                    <?php echo $_smarty_tpl->tpl_vars['objCategory']->value->getTitle();?>

                </span>

            </a>

		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		
		<!-- fin du foreach -->

	</div>

</div>

<div class="bn_gap-100"></div>
<?php }
}
