<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-07 07:48:28
  from 'C:\Users\disiitp10\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\eventsAdd.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e3d164ce2d380_21046034',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1a72cf38b6ea5b65f52ae9c0e983f4dad90148f9' => 
    array (
      0 => 'C:\\Users\\disiitp10\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\eventsAdd.tpl',
      1 => 1581060214,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e3d164ce2d380_21046034 (Smarty_Internal_Template $_smarty_tpl) {
?><form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label for="inputName">Nom de l'événement :</label>
		<input type="text" name="name" class="form-control" id="inputName" value="<?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getName();?>
" required>
	</div>
	

	<div class="form-group">
		<label for="inputStartDate">Date de début :</label>
		<input type="date" name="start_date" class="form-control" id="inputStartDate" value="<?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getStart_date();?>
" required>
	</div>

    <div class="form-group">
		<label for="inputEndDate">Date de fin :</label>
		<input type="date" name="end_date" class="form-control" id="inputEndDate" value="<?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getEnd_date();?>
" required>
	</div>

    <div class="form-group">
		<label for="inputCapacity">Nombre de personnes possibles :</label>
		<input type="number" name="capacity" class="form-control" id="inputEndDate" value="<?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getCapacity();?>
" required>
	</div>

	<div class="form-group">

		<div class="form-group">
			<?php if ((!empty($_smarty_tpl->tpl_vars['objEvent']->value->getImg()))) {?>
				<div>
					<img src="<?php echo base_url('uploads/events/');
echo $_smarty_tpl->tpl_vars['objEvent']->value->getImg();?>
" alt="" class="w-25 py-4 border-light">
				</div>


				<label for="inputImg">Changer l'image :</label>
			{ else }

				<label for="inputImg">Uploader une image :</label>

			<?php }?>

			<input type="file" class="form-control-file" id="inputImg" name="img" accept=".jpg, .jpeg, .png, .gif">
			<small id="fileHelp" class="form-text text-muted">Taille maximum : 2 mo</small>
		</div>

		
	</div>

	<div class="form-group">
		<label for="inputContent">Contenu :</label>
		<textarea name="content" class="form-control" id="inputContent"  required><?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getContent();?>
</textarea>
	</div>

	<button type="submit" class="btn btn-primary"><?php echo $_smarty_tpl->tpl_vars['buttonSubmit']->value;?>
</button> <a href="<?php echo base_url('events/listPage');?>
" class="btn btn-dark"><?php echo $_smarty_tpl->tpl_vars['buttonCancel']->value;?>
</a>
</form><?php }
}
