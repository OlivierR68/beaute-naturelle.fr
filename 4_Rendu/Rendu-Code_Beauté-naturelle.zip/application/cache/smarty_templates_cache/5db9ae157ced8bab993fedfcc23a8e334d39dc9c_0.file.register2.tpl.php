<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-09 13:25:28
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\register2.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e400848c31636_14635169',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5db9ae157ced8bab993fedfcc23a8e334d39dc9c' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\register2.tpl',
      1 => 1581254726,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e400848c31636_14635169 (Smarty_Internal_Template $_smarty_tpl) {
}
}
