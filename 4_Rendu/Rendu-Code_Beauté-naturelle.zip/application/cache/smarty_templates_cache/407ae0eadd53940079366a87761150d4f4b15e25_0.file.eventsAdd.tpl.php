<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-16 10:07:57
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\eventsAdd.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e49147d8e2736_08254617',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '407ae0eadd53940079366a87761150d4f4b15e25' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\eventsAdd.tpl',
      1 => 1581847327,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e49147d8e2736_08254617 (Smarty_Internal_Template $_smarty_tpl) {
?><form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label for="inputName">Nom de l'événement :</label>
		<input type="text" name="name" class="form-control" id="inputName" value="<?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getName();?>
" required>
	</div>
	

	<div class="form-group">
		<label for="inputStartDate">Date :</label>
		<input type="date" name="start_date" class="form-control" id="inputStartDate" value="<?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getStart_date();?>
" required>
	</div>

    <div class="form-group">
		<label for="inputCapacity">Nombre de personnes possibles :</label>
		<input type="number" name="capacity" class="form-control" id="inputEndDate" value="<?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getCapacity();?>
" required>
	</div>

	<div class="form-group">

		<div class="form-group">
			<?php if ((!empty($_smarty_tpl->tpl_vars['objEvent']->value->getImg()))) {?>
				<div>
					<img src="<?php echo base_url('uploads/events/');
echo $_smarty_tpl->tpl_vars['objEvent']->value->getImg();?>
" alt="" class="w-25 py-4 border-light">
				</div>


				<label for="inputImg">Changer l'image :</label>
			<?php } else { ?>

				<label for="inputImg">Uploader une image :</label>

			<?php }?>

			<input type="file" class="form-control-file" id="inputImg" name="img" accept=".jpg, .jpeg, .png, .gif">
			<small id="fileHelp" class="form-text text-muted">Taille maximum : 2 mo<br>Taille conseillée : 1920x500 px</small>
		</div>

		
	</div>

	<div class="form-group">
		<label for="inputContent">Contenu :</label>
		<textarea name="content" class="form-control" id="inputContent"  required><?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getContent();?>
</textarea>
	</div>

	<button type="submit" class="btn btn-primary"><?php echo $_smarty_tpl->tpl_vars['buttonSubmit']->value;?>
</button> <a href="<?php echo base_url('events/listPage');?>
" class="btn btn-dark"><?php echo $_smarty_tpl->tpl_vars['buttonCancel']->value;?>
</a>
</form><?php }
}
