<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 19:34:28
  from '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/front/templates/admin-top-bar.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e4847c472bed7_67463250',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f2d8556b2c7d30c105d6d6c408d64cb896dbd6a5' => 
    array (
      0 => '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/front/templates/admin-top-bar.tpl',
      1 => 1581489141,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e4847c472bed7_67463250 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- TOP BAR ADMIN -->
<div class="bg-dark">
	<nav class="navbar navbar-expand-lg navbar-dark container">
		<a class="navbar-brand" href="<?php echo base_url('dashboard');?>
"><i class="fas fa-user-cog"></i> <?php echo $_SESSION['profil_libelle'];?>
</a>
		<button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent2" aria-controls="navbarSupportedContent2" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent2">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
					<a  class="nav-link" href="<?php echo base_url('dashboard');?>
"><i class="fas fa-tachometer-alt mr-2"></i>Tableau de bord</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo base_url('images/back');?>
"><span class="bn_cube">0</span> Événements</a>
				</li>

				<li class="nav-item">
					<a class="nav-link" href="<?php echo base_url('events/back');?>
"><span class="bn_cube">524</span> Images</a>
				</li>


			</ul>
		</div>
	</nav>

</div>
<?php }
}
