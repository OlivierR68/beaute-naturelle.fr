<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 18:13:36
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\edit_profile.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e4834d054dac7_26113261',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '31bce8a9f0b06cf47a59b33f818f32db87c4bead' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\edit_profile.tpl',
      1 => 1581578781,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e4834d054dac7_26113261 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\third_party\\smarty\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>
<div>
    <div class="container">
        <?php echo form_open_multipart('','class="form-signin" autocomplete="something-new"');?>

        <div class="row">
            <div class="col-12 col-md-3 d-flex justify-content-center">
                <div>

                    <img class="w-100 img-fluid border" src="<?php echo base_url('uploads/avatar/');
echo $_smarty_tpl->tpl_vars['objUser']->value->getAvatar();?>
" alt="">
                    <div class="custom-file my-2">
                        <input type="file" name="avatar" class="form-control-file " accept="image/png, image/jpeg" id="inputAvatar">
                    </div>
                    <div>
                        <span class="small text-muted">Taille : 300x300 pixels, max 2 Mo</span>
                    </div>
                    <div class="mt-3">
                        <p class="small text-muted"><b>Profil :</b> <?php echo $_smarty_tpl->tpl_vars['objUser']->value->getProfil_libelle();?>
<br>
                            <b>Inscrit depuis le :</b> <?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['objUser']->value->getInscription_date(),"%d/%m/%Y");?>
</p>
                    </div>
                </div>

            </div>

            <div class="col-12 col-md-9">

                <div class="form-row">
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['inputArray']->value, 'arrGroup');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['arrGroup']->value) {
?>
                        <div class="form-group col-12 col-md-6">
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arrGroup']->value, 'input');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['input']->value) {
?>

                                <?php echo $_smarty_tpl->tpl_vars['input']->value;?>

                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </div>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

                    <div class="form-group col-12 col-md-6">
                        <label for="inputEmail" class="small text-muted">Sexe</label>
                        <select id="inputGender" name="gender" class="form-control">
                            <option>--</option>
                            <option <?php if ($_smarty_tpl->tpl_vars['objUser']->value->getGender() == 1) {?>selected<?php }?> value="1">Homme</option>
                            <option <?php if ($_smarty_tpl->tpl_vars['objUser']->value->getGender() == 2) {?>selected<?php }?> value="2">Femme</option>
                        </select>
                    </div>


                </div>
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn bn_btn-green">MODIFIER</button>

                </div>

            </div>


        </div>
        <?php echo form_close();?>

        <hr>
        <div class="bn_gap-100"></div>


    </div>
</div>
<?php }
}
