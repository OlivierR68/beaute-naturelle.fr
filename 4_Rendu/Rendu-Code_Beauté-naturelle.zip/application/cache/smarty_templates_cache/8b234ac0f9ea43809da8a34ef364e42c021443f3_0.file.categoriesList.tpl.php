<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 13:22:31
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\categoriesList.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e47f097431561_17438799',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8b234ac0f9ea43809da8a34ef364e42c021443f3' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\categoriesList.tpl',
      1 => 1581772949,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e47f097431561_17438799 (Smarty_Internal_Template $_smarty_tpl) {
?><div>

    <form class="mb-3" method="post">
        <div class="form-row align-items-center">

            <div class="col-auto my-1">
                <a class="btn btn-primary" href="<?php echo site_url('prestations/addEdit_cat');?>
" role="button">Ajouter une
                    Catégorie</a>
                <a class="btn btn-primary" href="<?php echo site_url('prestations/addEdit_subcat');?>
" role="button">Ajouter une
                    Sous-catégorie</a>
            </div>

        </div>
    </form>
</div>
<div class="row">
    <div class="col-6">


    </div>
</div>

<div class="row">

    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['display_list_1']->value, 'cat_obj');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['cat_obj']->value) {
?>
        <div class="col-12 col-md-6 col-lg-5 col-xl-3 mb-4">
            <div class="card shadow-sm">
                <img class="card-img-top img-fluid" src="<?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getHeaderUrl();?>
" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title text-center">#<?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getId();?>
 - <?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getTitle();?>
 </h5>
                    <p class="card-text"><?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getDescription();?>
 </p>
                    <ul>
                        <li><b>Slug : </b> <a target="_blank" href="<?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getUrl();?>
"><?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getSlug();?>
 </a>
                        </li>
                        <li><b>Header : </b> <a target="_blank"
                                                href="<?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getHeaderUrl();?>
"><?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getHeader();?>
</a></li>
                        <li><b>Thumb : </b> <a target="_blank" href="<?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getImgUrl();?>
"><?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getImg();?>
</a>
                        </li>
                    </ul>

                </div>

                <div class="d-flex justify-content-center p-1">
                    <a href="<?php echo site_url('prestations/visible_cat/');
echo $_smarty_tpl->tpl_vars['cat_obj']->value->getId();?>
"
                       class="mr-1 mb-1 btn <?php if ($_smarty_tpl->tpl_vars['cat_obj']->value->getVisible() == 1) {?>btn-success<?php } else { ?>btn-secondary<?php }?>"
                       title="Publier la catégorie">
                        <i class="fas fa-eye"></i>
                    </a>
                    <a href="<?php echo site_url('prestations/addEdit_cat/');
echo $_smarty_tpl->tpl_vars['cat_obj']->value->getId();?>
"
                       class="mr-1 mb-1 btn btn-primary" title="Modifier la catégorie"><i class="fas fa-edit"></i></a>
                    <a href="<?php echo site_url('prestations/delete_cat/');
echo $_smarty_tpl->tpl_vars['cat_obj']->value->getId();?>
"
                       data-href="<?php echo base_url('prestations/delete_cat/');
echo $_smarty_tpl->tpl_vars['cat_obj']->value->getId();?>
"
                       data-toggle="modal" data-target="#confirm-delete"
                       class="mr-1 mb-1 btn btn-danger" title="Supprimer la catégorie"><i class="fas fa-trash-alt"></i></a>
                </div>
                <hr>
                <ul class="list-group list-group-flush">
                    <?php if (!empty($_smarty_tpl->tpl_vars['display_list_2']->value[$_smarty_tpl->tpl_vars['cat_obj']->value->getId()])) {?>

                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['display_list_2']->value[$_smarty_tpl->tpl_vars['cat_obj']->value->getId()], 'subcat_obj');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['subcat_obj']->value) {
?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span><?php echo $_smarty_tpl->tpl_vars['subcat_obj']->value->getTitle();?>
</span>
                                <span>
                            <a href="<?php echo site_url('prestations/visible_subcat/');
echo $_smarty_tpl->tpl_vars['subcat_obj']->value->getId();?>
" class="btn <?php if ($_smarty_tpl->tpl_vars['subcat_obj']->value->getVisible() == 1) {?>btn-success<?php } else { ?>btn-secondary<?php }?> btn-sm"><i class="fas fa-eye"></i></a>
                            <a href="<?php echo site_url('prestations/addEdit_subcat/');
echo $_smarty_tpl->tpl_vars['subcat_obj']->value->getId();?>
" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                            <a href="<?php echo site_url('prestations/delete_subcat/');
echo $_smarty_tpl->tpl_vars['subcat_obj']->value->getId();?>
"
                               data-href="<?php echo base_url('prestations/delete_subcat/');
echo $_smarty_tpl->tpl_vars['subcat_obj']->value->getId();?>
"
                               data-toggle="modal" data-target="#confirm-delete"
                               class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></a>
                        </span>
                            </li>
                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    <?php }?>
                    <li class="list-group-item d-flex justify-content-between small text-muted">
                        <?php if (!empty($_smarty_tpl->tpl_vars['display_list_2']->value[$_smarty_tpl->tpl_vars['cat_obj']->value->getId()])) {?>
                            <?php echo count($_smarty_tpl->tpl_vars['display_list_2']->value[$_smarty_tpl->tpl_vars['cat_obj']->value->getId()]);?>
 Sous-catégories
                        <?php } else { ?>Catégorie vide<?php }?>
                        <br>
                            <a href="<?php echo site_url('prestations/addEdit_subcat');?>
?cat=<?php echo $_smarty_tpl->tpl_vars['cat_obj']->value->getId();?>
">Ajouter une sous-catégorie</a>
                        </li>

                </ul>

            </div>
        </div>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

</div>

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Confirmer la suppression
            </div>
            <div class="modal-body font-weight-bold">
                <p>Voulez-vous vraiment supprimer la catégorie ?</p>
                <div class="bg-danger rounded p-2 text-white ">
                    <i class="fas fa-exclamation-triangle mr-1"></i> Supprimer la catégorie entrainera la suppression de
                    toutes les sous-catégories et prestations enfants.
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal">Annuler</button>
                <a class="btn btn-danger btn-ok text-white">Supprimer</a>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="confirm-delete-subcat" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Confirmer la suppression
            </div>
            <div class="modal-body font-weight-bold">
                <p>Voulez-vous vraiment supprimer la sous-catégorie ?</p>
                <div class="bg-danger rounded p-2 text-white ">
                    <i class="fas fa-exclamation-triangle mr-1"></i> Supprimer la sous-catégorie entrainera la suppression de
                    toutes les prestations enfants.
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal">Annuler</button>
                <a class="btn btn-danger btn-ok text-white">Supprimer</a>
            </div>
        </div>
    </div>
</div>
<?php }
}
