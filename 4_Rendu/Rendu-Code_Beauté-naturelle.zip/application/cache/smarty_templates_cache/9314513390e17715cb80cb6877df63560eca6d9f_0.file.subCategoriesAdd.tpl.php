<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 15:03:10
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\subCategoriesAdd.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e48082e5ced03_56963390',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9314513390e17715cb80cb6877df63560eca6d9f' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\subCategoriesAdd.tpl',
      1 => 1581778990,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e48082e5ced03_56963390 (Smarty_Internal_Template $_smarty_tpl) {
?><form enctype="multipart/form-data" method="post">

    <div class="form-group">
        <label>Titre</label>
        <input type="text" name="title" class="form-control" value="<?php echo $_smarty_tpl->tpl_vars['subcat_obj']->value->getTitle();?>
" required>
    </div>

    <div class="form-group">
        <label >Catégorie Parent :</label>
        <select class="form-control" name="parent">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cat_list']->value, 'cat');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['cat']->value) {
?>
                <option value="<?php echo $_smarty_tpl->tpl_vars['cat']->value['cat_id'];?>
" <?php if ($_smarty_tpl->tpl_vars['subcat_obj']->value->getParent() == $_smarty_tpl->tpl_vars['cat']->value['cat_id']) {?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['cat']->value['cat_title'];?>
</option>
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </select>
    </div>

    <div class="form-group">
        <div>
            <label for="inputVisible">Visible au public :</label>
        </div>

        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="visible" id="inputVisible1" value="1" <?php if ($_smarty_tpl->tpl_vars['subcat_obj']->value->getVisible() == 1) {?>checked<?php }?> required >
            <label class="form-check-label" for="inputVisible1">Oui</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="visible" id="inputVisible2" value="0" <?php if ($_smarty_tpl->tpl_vars['subcat_obj']->value->getVisible() == 0) {?>checked<?php }?> required >
            <label class="form-check-label" for="inputVisible2">Non</label>
        </div>
    </div>

    <button type="submit" class="btn btn-primary"><?php echo $_smarty_tpl->tpl_vars['buttonSubmit']->value;?>
</button> <a href="<?php echo base_url('prestations/listPage_cat');?>
" class="btn btn-dark"><?php echo $_smarty_tpl->tpl_vars['buttonCancel']->value;?>
</a>
    <?php if (isset($_smarty_tpl->tpl_vars['next']->value)) {?>
        <a href="<?php echo base_url('prestations/delete_subcat/');
echo $_smarty_tpl->tpl_vars['subcat_obj']->value->getId();?>
" class="btn btn-danger"
           data-href="<?php echo base_url('prestations/delete_subcat/');
echo $_smarty_tpl->tpl_vars['subcat_obj']->value->getId();?>
"
           data-toggle="modal" data-target="#confirm-delete">
            Supprimer
        </a>
        <a href="<?php echo base_url('prestations/addEdit_subcat?cat=');
echo $_smarty_tpl->tpl_vars['subcat_obj']->value->getParent();?>
" class="btn btn-secondary">Ajouter une nouvelle sous-catégorie</a>
    <?php }?>

</form>

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Confirmer la suppression
            </div>
            <div class="modal-body font-weight-bold">
                <p>Voulez-vous vraiment supprimer la sous-catégorie ?</p>
                <div class="bg-danger rounded p-2 text-white ">
                    <i class="fas fa-exclamation-triangle mr-1"></i> Supprimer la sous-catégorie entrainera la suppression de
                    toutes les prestations enfants.
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal">Annuler</button>
                <a class="btn btn-danger btn-ok text-white">Supprimer</a>
            </div>
        </div>
    </div>
</div>


<?php }
}
