<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-11 10:19:18
  from 'C:\Users\disiitp10\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\edit_profile.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e427fa63a24b2_00171329',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5e26c8429b1fd3e86832b022bc07edf886e39dfd' => 
    array (
      0 => 'C:\\Users\\disiitp10\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\edit_profile.tpl',
      1 => 1581416340,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e427fa63a24b2_00171329 (Smarty_Internal_Template $_smarty_tpl) {
?><div>
    <div class="container">
        <?php echo form_open_multipart('','class="form-signin" autocomplete="something-new"');?>

        <?php echo form_hidden('id',$_smarty_tpl->tpl_vars['objUser']->value->getId());?>

        <?php echo form_hidden('profil_id',$_smarty_tpl->tpl_vars['objUser']->value->getProfil_id());?>

        <div class="row">
            <div class="col-12 col-md-3 d-flex justify-content-center">
                <div>
                    <div>
                        <span class="small text-muted">Inscrit depuis le 10/02/2020</span>
                    </div>

                    <img class="w-100 img-fluid" src="<?php echo base_url('uploads/avatar/');
echo $_smarty_tpl->tpl_vars['objUser']->value->getAvatar();?>
" alt="">
                    <div class="custom-file">
                        <input type="file" name="avatar" class="form-control-file " accept="image/png, image/jpeg" id="inputAvatar">
                    </div>

                </div>

            </div>

            <div class="col-12 col-md-9">

                <div class="form-row">

                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['inputArray']->value, 'arrGroup');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['arrGroup']->value) {
?>
                        <div class="form-group col-12 col-md-6">
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arrGroup']->value, 'input');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['input']->value) {
?>
                                <?php echo $_smarty_tpl->tpl_vars['input']->value;?>

                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </div>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

                    <div class="form-group col-12 col-md-6">
                        <label for="inputEmail" class="small text-muted">Sexe</label>
                        <select id="inputGender" name="gender" class="form-control">
                            <option>--</option>
                            <option <?php if ($_smarty_tpl->tpl_vars['objUser']->value->getGender() == 1) {?>selected<?php }?> value="1">Homme</option>
                            <option <?php if ($_smarty_tpl->tpl_vars['objUser']->value->getGender() == 2) {?>selected<?php }?> value="2">Femme</option>
                        </select>
                    </div>


                </div>
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn bn_btn-green">MODIFIER</button>

                </div>

            </div>


        </div>
        <?php echo form_close();?>

        <hr>
        <div class="bn_gap-100"></div>


    </div>
</div>
<?php }
}
