<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-16 13:57:24
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\event_infos.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e494a44823df8_96870014',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2d631639d01142c5bfd2962fa90e168b453102e2' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\event_infos.tpl',
      1 => 1581861442,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e494a44823df8_96870014 (Smarty_Internal_Template $_smarty_tpl) {
?><main class="container bn_content">
    <div class="bn_gap-25"></div>

    <p><?php echo $_smarty_tpl->tpl_vars['obj_event']->value->getContent();?>
</p>

    <div class=" bn_gap-25"></div>
    <p>Fermeture des inscriptions dans : <b><?php echo $_smarty_tpl->tpl_vars['obj_event']->value->daysBeforeExpired();?>
 jours</b></p>
    <div class="d-flex justify-content-between flex-wrap mb-1">
        <div class="d-flex flex-wrap">
            <?php echo $_smarty_tpl->tpl_vars['smart_block']->value;?>

        </div>

        <div class="d-flex">
            <div class="bn_bg-color-1 py-2 px-4 mb-1">
                <span class="text-light"><i class="fas fa-users"></i> Places disponibles : <?php echo count($_smarty_tpl->tpl_vars['participants_list']->value);?>
 / <?php echo $_smarty_tpl->tpl_vars['obj_event']->value->getCapacity();?>
</span>
            </div>
            <a class="d-block bg-dark py-2 px-4 ml-1 mb-1" href="<?php echo site_url('events');?>
">
                <span class="text-light">RETOUR</span>
            </a>

        </div>

    </div>

    <div class="bn_gap-10"></div>
    <hr>
    <h2>Participants : <?php echo count($_smarty_tpl->tpl_vars['participants_list']->value);?>
</h2>
    <div class="d-flex flex-wrap">
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['participants_list']->value, 'obj_user');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['obj_user']->value) {
?>

            <div class="card shadow-sm m-2" style="width: 15rem;">
                <img class="card-img-top border" src="<?php echo $_smarty_tpl->tpl_vars['obj_user']->value->getAvatarUrl();?>
" alt="Avatar de <?php echo $_smarty_tpl->tpl_vars['obj_user']->value->getPseudo();?>
">
                <div class="card-body d-flex justify-content-between">
                    <h5 class="card-title"><?php echo $_smarty_tpl->tpl_vars['obj_user']->value->getPseudo();?>
</h5><span><?php echo $_smarty_tpl->tpl_vars['obj_user']->value->getShortInfos();?>
</span>
                </div>
            </div>

        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

    </div>

    <div class="bn_gap-25"></div>

</main><?php }
}
