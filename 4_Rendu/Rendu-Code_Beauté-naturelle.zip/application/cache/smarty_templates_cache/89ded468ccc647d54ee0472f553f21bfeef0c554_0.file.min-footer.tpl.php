<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-11 12:54:28
  from '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/front/templates/min-footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e42a404c10c27_38096437',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '89ded468ccc647d54ee0472f553f21bfeef0c554' => 
    array (
      0 => '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/front/templates/min-footer.tpl',
      1 => 1581056614,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e42a404c10c27_38096437 (Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
 src="https://www.google.com/recaptcha/api.js?render=6LfwetYUAAAAAFXB6Cd1n0hKfTlMTsaSvJA6FeVf"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
>
        grecaptcha.ready(function() {
            grecaptcha.execute('6LfwetYUAAAAAFXB6Cd1n0hKfTlMTsaSvJA6FeVf', {action: 'homepage'}).then(function(token) {
            document.getElementById("token").value = token;
            });
        });
    <?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo base_url('assets/js/main.js');?>
"><?php echo '</script'; ?>
>
</div>
</body>
</html>
<?php }
}
