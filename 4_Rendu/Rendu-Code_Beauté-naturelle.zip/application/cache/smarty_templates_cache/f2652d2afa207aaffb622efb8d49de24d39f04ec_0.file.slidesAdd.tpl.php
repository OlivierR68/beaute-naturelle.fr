<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 19:34:36
  from '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/back/slidesAdd.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e4847cc21c212_44816374',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f2652d2afa207aaffb622efb8d49de24d39f04ec' => 
    array (
      0 => '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/back/slidesAdd.tpl',
      1 => 1581776550,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e4847cc21c212_44816374 (Smarty_Internal_Template $_smarty_tpl) {
?>
<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label for="inputLibelle">Libelle :</label>
		<input type="text" name="libelle" class="form-control" id="inputLibelle" value="<?php echo $_smarty_tpl->tpl_vars['objSlide']->value->getLibelle();?>
">
	</div>

	<div class="form-group">
		<label for="inputOrder">Ordre :</label>
		<input type="number" min="0" max="100" name="order" class="form-control" id="inputOrder" value="<?php echo $_smarty_tpl->tpl_vars['objSlide']->value->getOrder();?>
">
	</div>

	<div class="form-group">
		<div>
			<label for="inputVisible">Visible au public :</label>
		</div>

		<div class="form-check form-check-inline">
			<input class="form-check-input" type="radio" name="visible" id="inputVisible1" value="1" <?php if ($_smarty_tpl->tpl_vars['objSlide']->value->getVisible() == 1) {?>checked<?php }?> required >
			<label class="form-check-label" for="inputVisible1">Oui</label>
		</div>
		<div class="form-check form-check-inline">
			<input class="form-check-input" type="radio" name="visible" id="inputVisible2" value="0" <?php if ($_smarty_tpl->tpl_vars['objSlide']->value->getVisible() == 0) {?>checked<?php }?> required >
			<label class="form-check-label" for="inputVisible2">Non</label>
		</div>
	</div>

	<div class="form-group">
		<?php if ((!empty($_smarty_tpl->tpl_vars['objSlide']->value->getImg()))) {?>
			<div>
				<img src="<?php echo base_url('uploads/slider/');
echo $_smarty_tpl->tpl_vars['objSlide']->value->getImg();?>
" alt="" class="w-25 py-4 border-light">
			</div>


			<label for="inputImg">Changer l'image :</label>
		<?php } else { ?>

			<label for="inputImg">Uploader une image :</label>

		<?php }?>

		<input type="file" class="form-control-file" id="inputImg" name="img" accept=".jpg, .jpeg, .png, .gif">
		<small id="fileHelp" class="form-text text-muted">Poids maximum : 2 mo <br>Dimensions conseillées : 1920x800 px</small>
	</div>


	<div class="form-group">
		<div>
			<label for="inputType">Taille :</label>
		</div>

		<div class="form-check form-check-inline">
			<input class="form-check-input" type="radio" name="type" id="inputType" value="h1" <?php if ($_smarty_tpl->tpl_vars['objSlide']->value->getType() == 'h1') {?>checked<?php }?> required >
			<label class="form-check-label" for="inlineRadio1">Grand</label>
		</div>
		<div class="form-check form-check-inline">
			<input class="form-check-input" type="radio" name="type" id="inputType" value="h2" <?php if ($_smarty_tpl->tpl_vars['objSlide']->value->getType() == 'h2') {?>checked<?php }?> required >
			<label class="form-check-label" for="inlineRadio2">Moyen</label>
		</div>
	</div>

	<div class="form-group">
		<label for="inputTitle">Titre :</label>
		<input type="text" name="title" class="form-control" id="inputTitle" value="<?php echo $_smarty_tpl->tpl_vars['objSlide']->value->getTitle();?>
">
	</div>

	<div class="form-group">
		<label for="inputText">Texte :</label>
		<input type="text" name="text" class="form-control" id="inputText" value="<?php echo $_smarty_tpl->tpl_vars['objSlide']->value->getText();?>
">
	</div>

	<button type="submit" class="btn btn-primary"><?php echo $_smarty_tpl->tpl_vars['buttonSubmit']->value;?>
</button> <a href="<?php echo base_url('slides/listPage');?>
" class="btn btn-dark"><?php echo $_smarty_tpl->tpl_vars['buttonCancel']->value;?>
</a>
	<a href="<?php echo base_url('slides/delete/');
echo $_smarty_tpl->tpl_vars['objSlide']->value->getId();?>
" data-href="<?php echo base_url('slides/delete/');
echo $_smarty_tpl->tpl_vars['objSlide']->value->getId();?>
"
	   data-toggle="modal" data-target="#confirm-delete" class="btn btn-danger">Supprimer</a>
</form>

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
	 aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				Confirmer la suppression
			</div>
			<div class="modal-body">
				Vous voulez vraiment supprimer le slide <b class="bn_user"></b>?
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-dark" data-dismiss="modal">Annuler</button>
				<a class="btn btn-danger btn-ok">Supprimer</a>
			</div>
		</div>
	</div>
</div><?php }
}
