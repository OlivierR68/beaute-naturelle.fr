<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 18:59:14
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\templates\content.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e483f82003778_12939084',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6d90ac2b8b8898e37af8b31822d7a5cc8294b138' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\templates\\content.tpl',
      1 => 1581793152,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./header.tpl' => 1,
    'file:./footer.tpl' => 1,
  ),
),false)) {
function content_5e483f82003778_12939084 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:./header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php if (!empty($_smarty_tpl->tpl_vars['ERRORS']->value)) {?>
    <div class="text-center mb-5">
        <div class="alert alert-danger w-25 m-auto" role="alert">
            <?php echo $_smarty_tpl->tpl_vars['ERRORS']->value;?>

        </div>
    </div>
<?php }?>

<?php if (!empty(flash_data('error'))) {?>
    <div class="text-center mb-5">
        <div class="alert alert-danger w-25 m-auto" role="alert">
            <?php echo flash_data('error');?>

        </div>
    </div>
<?php }?>

<?php if (!empty($_smarty_tpl->tpl_vars['SUCCESS']->value)) {?>
    <div class="text-center mb-5">
        <div class="alert alert-success w-25 m-auto" role="alert">
            <?php echo $_smarty_tpl->tpl_vars['SUCCESS']->value;?>

        </div>
    </div>
<?php }?>

<?php if (!empty(flash_data('success'))) {?>
    <div class="text-center mb-5">
        <div class="alert alert-success w-25 m-auto" role="alert">
            <?php echo flash_data('success');?>

        </div>
    </div>
<?php }?>

<?php echo $_smarty_tpl->tpl_vars['CONTENT']->value;?>

<?php $_smarty_tpl->_subTemplateRender("file:./footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<?php }
}
