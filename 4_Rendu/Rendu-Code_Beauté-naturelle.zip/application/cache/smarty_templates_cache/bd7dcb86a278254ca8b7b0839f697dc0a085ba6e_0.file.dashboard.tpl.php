<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-16 19:12:43
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\dashboard.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e49942b994ce2_34719115',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bd7dcb86a278254ca8b7b0839f697dc0a085ba6e' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\dashboard.tpl',
      1 => 1581880362,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e49942b994ce2_34719115 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\third_party\\smarty\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>
<hr>
<div class="row">
    <div class="col-12 col-lg-6">
        <h4 class="mb-4">Demande d'inscription à un événement:</h4>

        <div>
            <?php if (!empty($_smarty_tpl->tpl_vars['requests_data']->value)) {?>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['requests_data']->value, 'request');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['request']->value) {
?>
                <div class="m-2 bg-light border">
                    <div class="bg-dark text-light p-2 d-flex justify-content-between">
                        <span><b>Date de demande : </b><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['request']->value['event_user_date'],"%d/%m/%Y");?>
</span><span class="font-weight-bold">#<?php echo $_smarty_tpl->tpl_vars['request']->value['event_user_id'];?>
</span>
                    </div>
                    <div class="d-flex">
                        <div class="p-2 w-100">
                            <ul class="list-unstyled small">
                                <li><b>Utilisateur : </b><?php echo $_smarty_tpl->tpl_vars['request']->value['user_pseudo'];?>
</li>
                                <li><b>Nom : </b><?php echo $_smarty_tpl->tpl_vars['request']->value['user_last_name'];?>
</li>
                                <li><b>Prénom : </b><?php echo $_smarty_tpl->tpl_vars['request']->value['user_first_name'];?>
</li>
                                <li><b>Email : </nr></b><?php echo $_smarty_tpl->tpl_vars['request']->value['user_email'];?>
</li>
                            </ul>
                        </div>
                        <div class="p-2 w-100">
                            <ul class="list-unstyled small">
                                <li><b>Événement : <br></b><a target="_blank" href="<?php echo site_url('events/ev/');
echo $_smarty_tpl->tpl_vars['request']->value['event_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['request']->value['event_name'];?>
</a></li>
                                <li><b>Date : </b><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['request']->value['event_start_date'],"%d/%m/%Y");?>
</li>
                                <li class="<?php if ($_smarty_tpl->tpl_vars['request']->value['event_filling'] == $_smarty_tpl->tpl_vars['request']->value['event_capacity']) {?>text-danger<?php }?>"><b>Capacité : </b><?php echo $_smarty_tpl->tpl_vars['request']->value['event_filling'];?>
 / <?php echo $_smarty_tpl->tpl_vars['request']->value['event_capacity'];?>
</li>
                            </ul>
                        </div>
                        <div class="d-flex flex-column align-items-end ml-auto">
                            <?php if ($_smarty_tpl->tpl_vars['request']->value['event_filling'] < $_smarty_tpl->tpl_vars['request']->value['event_capacity']) {?>
                                <div class="w-100">
                                    <a class="d-block bg-primary py-2 px-4 text-light mt-1"
                                       href="<?php echo site_url('events/accept_user');?>
/<?php echo $_smarty_tpl->tpl_vars['request']->value['event_id'];?>
/<?php echo $_smarty_tpl->tpl_vars['request']->value['user_id'];?>
">
                                       Accepter
                                    </a>
                                </div>
                            <?php }?>
                            <div class="w-100">
                                <a class="d-block bg-danger py-2 px-4 text-light mt-1"
                                   href="<?php echo site_url('events/refuse_user');?>
/<?php echo $_smarty_tpl->tpl_vars['request']->value['event_id'];?>
/<?php echo $_smarty_tpl->tpl_vars['request']->value['user_id'];?>
">
                                    Refuser
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            <?php } else { ?>
                <div class="bg-light text-muted p-2 text-center">Aucune demande pour l'instant</div>
            <?php }?>
        </div>

    </div>
    <div class="col-12 col-lg-6">
        <h4 class="mb-4">Demande d'ajout d'image :</h4>
        <div>
            <?php if (!empty($_smarty_tpl->tpl_vars['requests_img']->value)) {?>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['requests_img']->value, 'request');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['request']->value) {
?>
                    <div class="m-2 bg-light border">
                        <div class="bg-dark text-light p-2 d-flex justify-content-between">
                            <span><b>Date de publication : </b><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['request']->value['img_publi_date'],"%d/%m/%Y");?>
</span><span class="font-weight-bold">#<?php echo $_smarty_tpl->tpl_vars['request']->value['img_id'];?>
</span>
                        </div>
                        <div class="d-flex">
                            <div class="p-2 w-100">
                                <ul class="list-unstyled small">
                                    <li><b>Utilisateur : </b><?php echo $_smarty_tpl->tpl_vars['request']->value['user_pseudo'];?>
</li>
                                    <li><b>Nom : </b><?php echo $_smarty_tpl->tpl_vars['request']->value['user_last_name'];?>
</li>
                                    <li><b>Prénom : </b><?php echo $_smarty_tpl->tpl_vars['request']->value['user_first_name'];?>
</li>
                                    <li><b>Email : </nr></b><?php echo $_smarty_tpl->tpl_vars['request']->value['user_email'];?>
</li>
                                </ul>
                            </div>
                            <div class="p-2 w-100">
                                <ul class="list-unstyled small">
                                    <li><b>Événement : </b><?php echo $_smarty_tpl->tpl_vars['request']->value['img_libelle'];?>
</a></li>
                                    <li><b>Source : </b><a href="<?php echo site_url('uploads/album/');
echo $_smarty_tpl->tpl_vars['request']->value['img_src'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['request']->value['img_src'];?>
</a></li>
                                    <li><b>Description : </b><?php echo $_smarty_tpl->tpl_vars['request']->value['img_description'];?>
</li>
                                </ul>
                            </div>
                            <div class="d-flex flex-column align-items-end ml-auto">
                                    <div class="w-100">
                                        <a class="d-block bg-primary py-2 px-4 text-light mt-1"
                                           href="<?php echo site_url('images/accept');?>
/<?php echo $_smarty_tpl->tpl_vars['request']->value['img_id'];?>
">
                                            Autoriser
                                        </a>
                                    </div>

                                <div class="w-100">
                                    <a class="d-block bg-danger py-2 px-4 text-light mt-1"
                                       href="<?php echo site_url('images/delete');?>
/<?php echo $_smarty_tpl->tpl_vars['request']->value['img_id'];?>
">
                                        Supprimer
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            <?php } else { ?>
                <div class="bg-light text-muted p-2 text-center">Aucune demande pour l'instant</div>
            <?php }?>
        </div>
    </div>

</div>
<?php }
}
