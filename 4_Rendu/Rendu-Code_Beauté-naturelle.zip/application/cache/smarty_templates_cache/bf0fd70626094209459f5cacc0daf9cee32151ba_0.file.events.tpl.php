<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-16 13:17:10
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\events.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e4940d66d3a78_04973843',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bf0fd70626094209459f5cacc0daf9cee32151ba' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\events.tpl',
      1 => 1581859029,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e4940d66d3a78_04973843 (Smarty_Internal_Template $_smarty_tpl) {
?>
<main class="container bn_content">

<!-- Foreach ici -->
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arrEvents']->value, 'objEvent');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['objEvent']->value) {
?>
		<article>
			<div class="row">
				<div class="col-4">

					<div class="border" style="width: 350px; height: 270px; background-image: url('<?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getImgUrl();?>
'); background-size: cover; background-position: center;">
					</div>

				</div>

				
				<div class="col-8">
					<span class="bn_h2-pre">Le <?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getStart_date_form();?>
</span>
					<h2><?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getName();?>
</h2>
					<p><?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getContent();?>
</p>
					<div>
						<span class="bn_h2-pre"><i class="fas fa-users"></i> Places disponibles : <?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getFilling();?>
 / <?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getCapacity();?>
</span>
					</div>
					<div class="bn_gap-10"></div>
					<div>
						<a  href="<?php echo $_smarty_tpl->tpl_vars['objEvent']->value->getUrl();?>
" class="btn bn_btn-green text-uppercase">EN SAVOIR PLUS</a>
					</div>
				</div>
			</div>
		</article>
		<div class="bn_gap-25"></div>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
<!-- fin du foreach -->

</main>

<div class="bn_gap-100"></div>

<?php }
}
