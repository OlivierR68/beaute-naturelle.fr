<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-11 12:54:28
  from '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/front/templates/min-header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e42a404c0b109_01718685',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '33650cca81d650d7ef9e07d4d9b98cad02c6fd49' => 
    array (
      0 => '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/front/templates/min-header.tpl',
      1 => 1581056614,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e42a404c0b109_01718685 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
		  content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Document</title>

	<link rel="shortcut icon" href="<?php echo base_url("assets/favicon.ico");?>
" type="image/x-icon">
	<link rel="icon" href="<?php echo base_url('assets/favicon.png');?>
 type="image/png">
	<link rel="icon" sizes="32x32" href="<?php echo base_url("assets/favicon-32.png");?>
" type="image/png">
	<link rel="icon" sizes="64x64" href="<?php echo base_url("assets/favicon-64.png");?>
" type="image/png">
	<link rel="icon" sizes="96x96" href="<?php echo base_url("assets/favicon-96.png");?>
" type="image/png">


	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700|Lora&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/simple.css');?>
">
	<?php echo '<script'; ?>
 src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer><?php echo '</script'; ?>
>
</head>
<body>
<div class="container">





<?php }
}
