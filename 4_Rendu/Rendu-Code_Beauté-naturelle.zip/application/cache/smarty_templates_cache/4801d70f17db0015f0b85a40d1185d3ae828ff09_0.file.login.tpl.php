<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-11 17:56:22
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e42eac6ab3754_14204761',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4801d70f17db0015f0b85a40d1185d3ae828ff09' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\login.tpl',
      1 => 1581405382,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e42eac6ab3754_14204761 (Smarty_Internal_Template $_smarty_tpl) {
?><form class="form-signin" method="post">

    <div class="text-center my-4">
        <img class="mb-4" src="<?php echo base_url('./assets/img/logo.svg');?>
" alt="logo beauté-naturelle" width="140" height="140">
        <h1 class="h3 mb-3 font-weight-normal"><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
</h1>
    </div>

    <?php if (empty($_SESSION['login'])) {?>
    <div class="form-label-group">
        <input type="text" name="email" id="inputEmail" class="form-control" placeholder="Email" required autofocus>
        <label for="inputEmail">Email</label>
    </div>
    <div class="form-label-group">
        <input type="password" name="pwd" id="inputPassword" class="form-control" placeholder="Mot de Passe" required>
        <label for="inputPassword">Mot de Passe</label>
    </div>

    <input type="hidden" id="token" name="token">

    <button class="btn btn-lg btn-primary btn-block" type="submit">Se Connecter</button>
    <?php } else { ?>
        <p class="text-center">Vous êtes déjà connecter. <br><a href="<?php echo site_url('users/disconnect');?>
">Cliquez ici pour vous déconnecter</a>.</p>
    <?php }?>

    <div class="text-center mt-3">
        <p>Vous n'avez pas de compte ? <a href="<?php echo site_url('users/register');?>
">Inscrivez-vous !</a></p>
        <p><a href="<?php echo site_url();?>
">Page d'accueil</a><?php if (isset($_SERVER['HTTP_REFERER'])) {?> | <a href="<?php echo $_SERVER['HTTP_REFERER'];?>
">Page précédente</a><?php }?></p>
    </div>

    <p class="mt-5 mb-3 text-muted text-center small">Tous droits réservés 2010-2020 - Beauté Naturelle<br>Site réalisé par
        <a href="http://webolive.fr" target="_blank">Studio 241</a></p>
</form>
<?php }
}
