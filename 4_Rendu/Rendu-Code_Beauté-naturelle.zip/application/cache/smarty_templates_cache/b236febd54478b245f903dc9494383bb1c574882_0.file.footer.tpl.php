<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-14 08:41:56
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e465d549aacb1_77406612',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b236febd54478b245f903dc9494383bb1c574882' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\templates\\footer.tpl',
      1 => 1581669710,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e465d549aacb1_77406612 (Smarty_Internal_Template $_smarty_tpl) {
?></main>
<footer class="py-4 bg-light mt-auto">
	<div class="container-fluid">
		<div class="d-flex align-items-center justify-content-between small">
			<div class="text-muted">Tous droits réservés &copy; beauté-naturelle.fr <?php echo date("Y");?>
</div>
			<div>
				<a href="<?php echo site_url('pages/politique');?>
">Politique de confidentialités</a>
				&middot;
				<a href="<?php echo site_url('pages/mentions');?>
">Mentions légales</a>
			</div>
		</div>
	</div>
</footer>
</div>
</div>
<?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo base_url('assets/js/scripts.js');?>
"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
>
	$('#confirm-delete').on('show.bs.modal', function(e) {
		$(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));

	});
<?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo base_url('assets/demo/datatables-demo.js');?>
"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
