<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-16 18:03:15
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\imagesAdd.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e4983e3cc5143_62136679',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2bead113ed287b46b941d70c6a53a1368354d8eb' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\imagesAdd.tpl',
      1 => 1581876190,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e4983e3cc5143_62136679 (Smarty_Internal_Template $_smarty_tpl) {
?><form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label for="inputName">Nom de l'image :</label>
		<input type="text" name="libelle" class="form-control" id="inputName" value="<?php echo $_smarty_tpl->tpl_vars['objImage']->value->getLibelle();?>
">
	</div>

	<div class="form-group">
		<label for="inputName">Description</label>
		<input type="text" name="description" class="form-control" id="inputName" value="<?php echo $_smarty_tpl->tpl_vars['objImage']->value->getDescription();?>
">
	</div>

	<div class="form-group">
		<label for="inputName">Publier</label>
		<select name="validation">
			<option value="1">Oui</option>
			<option value="0">Non</option>
		</select>
	</div>

	<div class="form-group">

		<div class="form-group">
			<?php if ((!empty($_smarty_tpl->tpl_vars['objImage']->value->getId()))) {?>
				<div>
					<img src="<?php echo base_url('uploads/album/');
echo $_smarty_tpl->tpl_vars['objImage']->value->getSrc();?>
" alt="<?php echo $_smarty_tpl->tpl_vars['objImage']->value->getDescription();?>
" class="w-25 py-4 border-light">
				</div>


				<label for="inputImg">Changer l'image :</label>
			<?php } else { ?>

				<label for="inputImg">Uploader une image :</label>

			<?php }?>

			<input type="file" class="form-control-file" id="inputImg" name="img" accept=".jpg, .jpeg, .png, .gif" required>
			<small id="fileHelp" class="form-text text-muted">Taille maximum : 2 mo</small>
		</div>

	</div>

	<button type="submit" class="btn btn-primary"><?php echo $_smarty_tpl->tpl_vars['buttonSubmit']->value;?>
</button> <a href="<?php echo base_url('images/listPage');?>
" class="btn btn-dark"><?php echo $_smarty_tpl->tpl_vars['buttonCancel']->value;?>
</a>
</form><?php }
}
