<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-16 20:31:54
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\subscribersList.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e49a6ba084b69_10293145',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2885518d7bfc658f2930b0ee99d4515adf81c877' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\subscribersList.tpl',
      1 => 1581885111,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e49a6ba084b69_10293145 (Smarty_Internal_Template $_smarty_tpl) {
?><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">
    Ajouter un abonné
</button>

<a href="<?php echo site_url('newsletter/export_csv');?>
" type="button" class="btn btn-primary">
    Exporter la liste en .csv
</a>



<div class="table-responsive mt-3">
    <table class="table table-bordered table-sm" id="dataTable" width="100%" cellspacing="0">
        <thead>
        <tr>
            <th>Id</th>
            <th>Actions</th>
            <th>Email</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>Id</th>
            <th>Actions</th>
            <th>Email</th>
        </tr>
        </tfoot>
        <tbody>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['display_list']->value, 'item');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['item']->value) {
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['item']->value['subscriber_id'];?>
</td>
                <td class="bn_action nowrap" style="width: 175px">

                    <a href="<?php echo base_url('newsletter/delete/');
echo $_smarty_tpl->tpl_vars['item']->value['subscriber_id'];?>
"
                       data-href="<?php echo base_url('newsletter/delete/');
echo $_smarty_tpl->tpl_vars['item']->value['subscriber_id'];?>
"
                       data-toggle="modal" data-target="#confirm-delete" title="Supprimer">
                        <i class="fas fa-trash-alt text-danger"></i>
                    </a>

                </td>
                <td><?php echo $_smarty_tpl->tpl_vars['item']->value['subscriber_email'];?>
</td>

            </tr>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
    </table>
</div>


<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Confirmer la suppression
            </div>
            <div class="modal-body">
                Vous voulez vraiment supprimer cette abonné <b class="bn_user"></b>?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal">Annuler</button>
                <a class="btn btn-danger btn-ok">Supprimer</a>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Ajouter un nouvel abonné</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>Courriel</label>
                    <input type="email" class="form-control" name="email">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                <input type="submit" class="btn btn-primary" value="Ajouter">
            </div>
        </form>
    </div>
</div><?php }
}
