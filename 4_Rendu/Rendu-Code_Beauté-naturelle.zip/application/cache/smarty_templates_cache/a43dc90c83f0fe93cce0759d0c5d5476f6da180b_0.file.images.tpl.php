<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-13 07:26:47
  from 'C:\Users\disiitp10\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\images.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e44fa37883109_40389250',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a43dc90c83f0fe93cce0759d0c5d5476f6da180b' => 
    array (
      0 => 'C:\\Users\\disiitp10\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\images.tpl',
      1 => 1581578781,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e44fa37883109_40389250 (Smarty_Internal_Template $_smarty_tpl) {
?><main class="container bn_content">
    <?php if ($_smarty_tpl->tpl_vars['objUser']->value->getId() >= 0) {?>
        <a href="<?php echo site_url('user_images/user_addImg.tpl');?>
" type="button" name="name" class="form-control col-2 mb-4" id="inputName" >Ajouter une image</a>
    <?php }?>

        <div class="row no-gutters bn_galerie">

            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arrImages']->value, 'objImage');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['objImage']->value) {
?>                   

            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
                    
                    <a src="<?php echo base_url("uploads/album/");
echo $_smarty_tpl->tpl_vars['objImage']->value->getSrc();?>
" data-lightbox="roadtrip">
                    <div class="bn_galerie-img">
                        <img src="<?php echo base_url("uploads/album/");
echo $_smarty_tpl->tpl_vars['objImage']->value->getSrc();?>
" alt="Belle Photo">
                    </div>

                </a>
            </div>
            
            <!-- Fin du foreach -->
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>
</main>

<div class="bn_gap-100"></div>

<?php }
}
