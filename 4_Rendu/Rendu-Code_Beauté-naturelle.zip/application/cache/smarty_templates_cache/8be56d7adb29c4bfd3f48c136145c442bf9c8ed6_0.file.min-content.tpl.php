<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-11 12:54:28
  from '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/front/templates/min-content.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e42a404c04544_74986422',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8be56d7adb29c4bfd3f48c136145c442bf9c8ed6' => 
    array (
      0 => '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/front/templates/min-content.tpl',
      1 => 1581056614,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./min-header.tpl' => 1,
    'file:./min-footer.tpl' => 1,
  ),
),false)) {
function content_5e42a404c04544_74986422 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:./min-header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php if (isset($_smarty_tpl->tpl_vars['SUCCESS']->value)) {?>
    <div class="text-center" >
        <div class="alert alert-success d-inline" role="alert">
            <?php echo $_smarty_tpl->tpl_vars['SUCCESS']->value;?>

        </div>
    </div>
<?php }?>

<?php if (((flash_data('success') !== null ))) {?>
    <div class="alert alert-success text-center d-inline" role="alert">
        <?php echo flash_data('success');?>

    </div>
<?php }?>

<?php if (isset($_smarty_tpl->tpl_vars['ERRORS']->value)) {?>
    <div class="text-center" >
        <div class="alert alert-danger d-inline" role="alert">
            <?php echo $_smarty_tpl->tpl_vars['ERRORS']->value;?>

        </div>
    </div>
<?php }?>

<?php if (((flash_data('errors') !== null ))) {?>
    <div class="alert alert-danger text-center" role="alert">
        <?php echo flash_data('errors');?>

    </div>
<?php }?>

<?php echo $_smarty_tpl->tpl_vars['CONTENT']->value;?>

<?php $_smarty_tpl->_subTemplateRender("file:./min-footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
