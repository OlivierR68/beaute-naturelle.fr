<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 19:34:31
  from '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/back/slidesList.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e4847c7ed1c30_90219521',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '29bbc1c8a59c0278ea3dd81a67219a1976b4d50c' => 
    array (
      0 => '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/back/slidesList.tpl',
      1 => 1581784314,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e4847c7ed1c30_90219521 (Smarty_Internal_Template $_smarty_tpl) {
?><a class="btn btn-primary mb-3" href="<?php echo site_url('slides/addEdit');?>
" role="button">Ajouter un slide</a>

<div class="table-responsive">
    <table class="table table-bordered table-sm" id="dataTable" width="100%" cellspacing="0">
        <thead>
        <tr>
            <th>Id</th>
            <th>Ordre</th>
            <th>Actions</th>
            <th>Libelle</th>
            <th>Image</th>
            <th>Taille</th>
            <th>Titre</th>
            <th>Sous-titre</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>Id</th>
            <th>Ordre</th>
            <th>Actions</th>
            <th>Libelle</th>
            <th>Image</th>
            <th>Taille</th>
            <th>Titre</th>
            <th>Sous-titre</th>
        </tr>
        </tfoot>
        <tbody>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arrSlides']->value, 'objSlide');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['objSlide']->value) {
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['objSlide']->value->getId();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['objSlide']->value->getOrder();?>
</td>
                <td class="bn_action nowrap" style="width: 175px">

                    <a href="<?php echo base_url('slides/visible/');
echo $_smarty_tpl->tpl_vars['objSlide']->value->getId();?>
" title="Visibilité">
                        <i class="far fa-eye <?php if ($_smarty_tpl->tpl_vars['objSlide']->value->getVisible() == false) {?>text-muted<?php } else { ?>text-success<?php }?>"></i>
                    </a>

                    <a href="<?php echo base_url('slides/orderDown/');
echo $_smarty_tpl->tpl_vars['objSlide']->value->getId();?>
" title="Ordre +1">
                        <i class="far fa-plus-square"></i>
                    </a>

                    <a href="<?php echo base_url('slides/orderUp/');
echo $_smarty_tpl->tpl_vars['objSlide']->value->getId();?>
" title="Ordre -1">
                        <i class="far fa-minus-square"></i>
                    </a> |

                    <a href="<?php echo base_url('slides/copy/');
echo $_smarty_tpl->tpl_vars['objSlide']->value->getId();?>
" title="Copier">
                        <i class="far fa-copy"></i>
                    </a>
                    <a href="<?php echo base_url('slides/addEdit/');
echo $_smarty_tpl->tpl_vars['objSlide']->value->getId();?>
" title="Modifier">
                        <i class="far fa-edit"></i>
                    </a>
                    <a href="<?php echo base_url('slides/delete/');
echo $_smarty_tpl->tpl_vars['objSlide']->value->getId();?>
"
                       data-href="<?php echo base_url('slides/delete/');
echo $_smarty_tpl->tpl_vars['objSlide']->value->getId();?>
"
                       data-toggle="modal" data-target="#confirm-delete" title="Supprimer">
                        <i class="fas fa-trash-alt text-danger"></i>
                    </a>

                </td>
                <td><?php echo $_smarty_tpl->tpl_vars['objSlide']->value->getLibelle();?>
</td>
                <td><a target="_blank" href="<?php echo base_url('uploads/slider/');
echo $_smarty_tpl->tpl_vars['objSlide']->value->getImg();?>
"><?php echo $_smarty_tpl->tpl_vars['objSlide']->value->getImg();?>
</a></td>
                <td><?php echo $_smarty_tpl->tpl_vars['objSlide']->value->getTaille();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['objSlide']->value->getShortTitle(60);?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['objSlide']->value->getText();?>
</td>

            </tr>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
    </table>
</div>


<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
     aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Confirmer la suppression
            </div>
            <div class="modal-body">
                Vous voulez vraiment supprimer le slide <b class="bn_user"></b>?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal">Annuler</button>
                <a class="btn btn-danger btn-ok">Supprimer</a>
            </div>
        </div>
    </div>
</div><?php }
}
