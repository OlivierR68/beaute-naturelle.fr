<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 16:38:11
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\category.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e481e73f26053_23105360',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e1b7c4075447332ea4d8fa5379f61a53211cb381' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\category.tpl',
      1 => 1581784643,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e481e73f26053_23105360 (Smarty_Internal_Template $_smarty_tpl) {
?><main class="container bn_content">
    <?php if (isset($_smarty_tpl->tpl_vars['presta_table']->value) && !empty($_smarty_tpl->tpl_vars['presta_table']->value)) {?>


    <table class="table">
        <!-- Début 1er Foreach -->
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['presta_table']->value, 'sub_cat_presta', false, 'sub_cat_name');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['sub_cat_name']->value => $_smarty_tpl->tpl_vars['sub_cat_presta']->value) {
?>

        <thead class="bn_bg-color-1 bn_color-white">
            <td><?php echo $_smarty_tpl->tpl_vars['sub_cat_name']->value;?>
</td>
            <td>Durée</td>
            <td>Prix</td>
        </thead>
        <tbody>
            <!-- début 2eme Foreach -->
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['sub_cat_presta']->value, 'objPresta');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['objPresta']->value) {
?>
            <tr>
                <td>
                    <?php echo $_smarty_tpl->tpl_vars['objPresta']->value->getTitle();
if (!empty($_smarty_tpl->tpl_vars['objPresta']->value->getSubtext())) {?> :<br><span class="bn_small-text"><?php echo $_smarty_tpl->tpl_vars['objPresta']->value->getSubtext();?>
</span><?php }?>
                </td>
                <td class="text-nowrap"><?php echo $_smarty_tpl->tpl_vars['objPresta']->value->getDuration();?>
 min</td>
                <td class="text-nowrap"><?php echo $_smarty_tpl->tpl_vars['objPresta']->value->getPrice();?>
 €</td>
            </tr>
            <!-- Fin 2eme Foreach -->
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

        </tbody>

        <!-- Fin 1er Foreach -->
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </table>
    <div class="bn_gap-25"></div>
    <?php } else { ?>
        <p class="text-center">Catégorie Vide</p>

    <?php }?>
    <a href="<?php echo site_url('prestations');?>
" class="btn bn_btn-green">RETOUR</a>




</main>

<div class="bn_gap-100"></div>
<?php }
}
