<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-11 13:02:25
  from '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/back/usersList.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e42a5e18cf9e0_00064370',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4e53b46d4f2e42aa84de81e329a5dd28023d3db9' => 
    array (
      0 => '/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/views/back/usersList.tpl',
      1 => 1581056614,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e42a5e18cf9e0_00064370 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/home/ravoli/web/ravoli.formation-web-cci.aradev.fr/public_html/application/third_party/smarty/libs/plugins/modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>
<a class="btn btn-primary mb-3" href="<?php echo site_url('users/addEdit');?>
" role="button">Ajouter un Utilisateur</a>

<div class="table-responsive">
    <table class="table table-bordered table-sm" id="dataTable" width="100%" cellspacing="0">
        <thead>
        <tr>
            <th>id</th>
            <th>Actions</th>
            <th>Pseudo</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Profil</th>
            <th>Date D'inscription</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>id</th>
            <th>Actions</th>
            <th>Pseudo</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Profil</th>
            <th>Date D'inscription</th>
        </tr>
        </tfoot>
        <tbody>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arrUsers']->value, 'objUser');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['objUser']->value) {
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['objUser']->value->getId();?>
</td>
                <td class="bn_action nowrap">
                    <a href="<?php echo base_url('users/addEdit/');
echo $_smarty_tpl->tpl_vars['objUser']->value->getId();?>
" title="Modifier"><i
                                class="far fa-edit"></i></a>
                    <a href="<?php echo base_url('users/delete/');
echo $_smarty_tpl->tpl_vars['objUser']->value->getId();?>
"  data-href="<?php echo base_url('users/delete/');
echo $_smarty_tpl->tpl_vars['objUser']->value->getId();?>
" data-toggle="modal" data-target="#confirm-delete" title="Supprimer"><i
                                class="fas fa-trash-alt text-danger"></i></a>
                </td>
                <td><?php echo $_smarty_tpl->tpl_vars['objUser']->value->getPseudo();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['objUser']->value->getLast_name();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['objUser']->value->getFirst_name();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['objUser']->value->getEmail();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['objUser']->value->getProfil_libelle();?>
</td>
                <td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['objUser']->value->getInscription_date(),"%D");?>
</td>
            </tr>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
    </table>
</div>



<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Confirmer la suppression
            </div>
            <div class="modal-body">
                Vous voulez vraiment supprimer l'utilisateur <b class="bn_user"></b>?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a class="btn btn-danger btn-ok">Delete</a>
            </div>
        </div>
    </div>
</div><?php }
}
