<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-16 18:54:22
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\images.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e498fde830ba4_62346764',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ac6740783040fc2a632f208581484941cc4a67b9' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\images.tpl',
      1 => 1581879261,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e498fde830ba4_62346764 (Smarty_Internal_Template $_smarty_tpl) {
?><main class="container bn_content">
    <!-- Si utilisateur connecté alors on affiche le button d'upload d'image -->
    <?php if (isset($_SESSION['login'])) {?>
    <div class="bn_bg-color-1 p-2 d-flex justify-content-end">
        <button type="button" class="btn btn-light" data-toggle="modal" data-target="#exampleModal">
            Ajouter une image
        </button>
    </div>
    <?php }?>

        <div class="row no-gutters bn_galerie">

            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arrImages']->value, 'objImage');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['objImage']->value) {
?>                   

            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
                    
                    <a href="<?php echo base_url("uploads/album/");
echo $_smarty_tpl->tpl_vars['objImage']->value->getSrc();?>
" data-lightbox="roadtrip">
                    <div class="bn_galerie-img">
                        <img src="<?php echo base_url("uploads/album/");
echo $_smarty_tpl->tpl_vars['objImage']->value->getSrc();?>
" alt="<?php echo $_smarty_tpl->tpl_vars['objImage']->value->getDescription();?>
">
                    </div>

                </a>
            </div>
            
            <!-- Fin du foreach -->
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>
</main>

<div class="bn_gap-100"></div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form enctype="multipart/form-data" method="post">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ajouter une image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Nom de l'image :</label>
                        <input type="text" class="form-control" name="libelle" required>
                    </div>
                    <div class="form-group">
                        <label>Description :</label>
                        <input type="text" class="form-control" name="description" required>
                    </div>
                    <div class="form-group">
                        <input type="file" name="img" class="form-control-file" id="exampleFormControlFile1">
                        <small>Taille maximum : 2mo</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <a type="button" class="btn btn-secondary text-light" data-dismiss="modal">Annuler</a>
                    <input type="submit" class="btn btn-success text-light" value="Valider">
                </div>
            </form>
        </div>
    </div>
</div>
<?php }
}
