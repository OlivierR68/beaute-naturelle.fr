<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-11 17:56:22
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\templates\min-footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e42eac6b4bd01_44964261',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '26e9b093bd4af693e2619f93cde623faa8055bec' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\templates\\min-footer.tpl',
      1 => 1581060214,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e42eac6b4bd01_44964261 (Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
 src="https://www.google.com/recaptcha/api.js?render=6LfwetYUAAAAAFXB6Cd1n0hKfTlMTsaSvJA6FeVf"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
>
        grecaptcha.ready(function() {
            grecaptcha.execute('6LfwetYUAAAAAFXB6Cd1n0hKfTlMTsaSvJA6FeVf', {action: 'homepage'}).then(function(token) {
            document.getElementById("token").value = token;
            });
        });
    <?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo base_url('assets/js/main.js');?>
"><?php echo '</script'; ?>
>
</div>
</body>
</html>
<?php }
}
