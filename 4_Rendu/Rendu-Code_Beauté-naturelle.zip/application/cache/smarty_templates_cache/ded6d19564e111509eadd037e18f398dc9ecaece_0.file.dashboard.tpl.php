<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-11 07:43:09
  from 'C:\Users\disiitp10\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\dashboard.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e425b0d87d518_35345142',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ded6d19564e111509eadd037e18f398dc9ecaece' => 
    array (
      0 => 'C:\\Users\\disiitp10\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\dashboard.tpl',
      1 => 1581318881,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e425b0d87d518_35345142 (Smarty_Internal_Template $_smarty_tpl) {
?><p>Dashboard à faire</p>
<?php }
}
