<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 19:26:04
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\back\prestationsList.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e4845cc170905_39735567',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9320f6154a6bc718d32155d1571a98be2e5fdfca' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\back\\prestationsList.tpl',
      1 => 1581794762,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e4845cc170905_39735567 (Smarty_Internal_Template $_smarty_tpl) {
?>

<div>

    <form class="mb-3" method="get">
        <div class="form-row align-items-center">

            <div class="col-auto my-1">
                <a class="btn btn-primary" href="<?php echo site_url('prestations/addEdit');?>
" role="button">Ajouter une prestation</a>
            </div>

            <div class="col-auto my-1">
                <label class="mr-sm-2 sr-only" for="inputCat">Catégorie</label>
                <select class="custom-select mr-sm-2"  name="cat" id="inputCat">
                    <option class="text-muted" value="">Catégorie</option>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cat_list']->value, 'cat');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['cat']->value) {
?>
                        <option <?php if (isset($_GET['cat']) && $_GET['cat'] == $_smarty_tpl->tpl_vars['cat']->value['cat_id']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['cat']->value['cat_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['cat']->value['cat_title'];?>
</option>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </select>
            </div>

            <div class="col-auto my-1">
                <label class="mr-sm-2 sr-only" for="inputSubCat">Sub-Catégorie</label>
                <select class="custom-select mr-sm-2"  name="subcat" id="inputSubCat">
                    <option  class="text-muted" value="">Sous-catégorie</option>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['sub_cat_list']->value, 'sub_cat');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['sub_cat']->value) {
?>
                        <option <?php if (isset($_GET['subcat']) && $_GET['subcat'] == $_smarty_tpl->tpl_vars['sub_cat']->value['sub_cat_id']) {?>selected<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['sub_cat']->value['sub_cat_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['sub_cat']->value['sub_cat_title'];?>
</option>
                    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </select>
            </div>


            <div class="col-auto my-1">
                <button type="submit" class="btn btn-primary">Filtrer</button>
            </div>

        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-bordered table-sm" id="dataTable" width="100%" cellspacing="0">
        <thead>
        <tr>
            <th>Id</th>
            <th>Ordre</th>
            <th>Actions</th>
            <th>Titre</th>
            <th>Description</th>
            <th>Durée</th>
            <th>Prix</th>
            <th>Sous-Catégorie </th>
            <th>Catégorie </th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>Id</th>
            <th>Ordre</th>
            <th>Actions</th>
            <th>Titre</th>
            <th>Description</th>
            <th>Durée</th>
            <th>Prix</th>
            <th>Sous-Catégorie </th>
            <th>Catégorie </th>
        </tr>
        </tfoot>
        <tbody>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['display_list']->value, 'presta_obj');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['presta_obj']->value) {
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['presta_obj']->value->getId();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['presta_obj']->value->getOrder();?>
</td>
                <td class="bn_action nowrap" style="width: 175px">
                    <a href="<?php echo base_url('prestations/visible_presta/');
echo $_smarty_tpl->tpl_vars['presta_obj']->value->getId();?>
" title="Visibilité">
                        <i class="far fa-eye <?php if ($_smarty_tpl->tpl_vars['presta_obj']->value->getVisible() == false) {?>text-muted<?php } else { ?>text-success<?php }?>"></i>
                    </a>

                    <a href="<?php echo base_url('prestations/orderDown/');
echo $_smarty_tpl->tpl_vars['presta_obj']->value->getId();?>
" title="Ordre +1">
                        <i class="far fa-plus-square"></i>
                    </a>

                    <a href="<?php echo base_url('prestations/orderUp/');
echo $_smarty_tpl->tpl_vars['presta_obj']->value->getId();?>
" title="Ordre -1">
                        <i class="far fa-minus-square"></i>
                    </a> |

                    <a href="<?php echo base_url('prestations/copy_presta/');
echo $_smarty_tpl->tpl_vars['presta_obj']->value->getId();?>
" title="Copier">
                        <i class="far fa-copy"></i>
                    </a>
                    <a href="<?php echo base_url('prestations/addEdit/');
echo $_smarty_tpl->tpl_vars['presta_obj']->value->getId();?>
" title="Modifier"><i
                                class="far fa-edit"></i></a>
                    <a href="<?php echo base_url('prestations/delete/');
echo $_smarty_tpl->tpl_vars['presta_obj']->value->getId();?>
"
                       data-href="<?php echo base_url('prestations/delete/');
echo $_smarty_tpl->tpl_vars['presta_obj']->value->getId();?>
"
                       data-toggle="modal" data-target="#confirm-delete" title="Supprimer"><i
                                class="fas fa-trash-alt text-danger"></i></a>


                </td>
                <td><?php echo $_smarty_tpl->tpl_vars['presta_obj']->value->getShortTitle();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['presta_obj']->value->getShortSubtext();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['presta_obj']->value->getDuration();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['presta_obj']->value->getPrice();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['presta_obj']->value->getSub_cat_title();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['presta_obj']->value->getCat_title();?>
</td>
            </tr>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
    </table>
</div>



<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Confirmer la suppression
            </div>
            <div class="modal-body">
                Vous voulez vraiment supprimer la prestation <b class="bn_user"></b>?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-dismiss="modal">Annuler</button>
                <a class="btn btn-danger btn-ok">Supprimer</a>
            </div>
        </div>
    </div>
</div><?php }
}
