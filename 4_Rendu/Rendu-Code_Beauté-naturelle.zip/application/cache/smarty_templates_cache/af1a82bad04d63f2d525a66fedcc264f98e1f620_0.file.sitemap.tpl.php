<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-12 21:41:58
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\front\sitemap.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e447126f0fe03_58491760',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'af1a82bad04d63f2d525a66fedcc264f98e1f620' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\front\\sitemap.tpl',
      1 => 1581009056,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e447126f0fe03_58491760 (Smarty_Internal_Template $_smarty_tpl) {
?><main class="container bn_content">
	<ul class="bn_site-map-ul w-25 mx-auto">
		<li><a href="index.html">Accueil</a></li>
		<li>Évènements</li>
		<li>
			<a href="institut.html">L'Institut</a>
			<ul>
				<li><a href="./prestations/epilation.html">Épilations</a></li>
				<li><a href="./prestations/mains-pieds.html">Mains & Pieds</a></li>
				<li><a href="./prestations/regard.html">Regard</a></li>
				<li><a href="./prestations/visage.html">Visage</a></li>
				<li><a href="./prestations/minceur.html">Minceur</a></li>
				<li><a href="./prestations/carita.html">Carita</a></li>
				<li><a href="./prestations/spa.html">SPA</a></li>
				<li><a href="./prestations/hommes.html">Hommes</a></li>
			</ul>
		</li>
		<li><a href="magasin.html">Le Magasin</a></li>
		<li><a href="galerie.html">Galerie</a></li>
		<li><a href="contact.html">Contact</a></li>
	</ul>

</main>

<div class="bn_gap-100"></div>
<?php }
}
