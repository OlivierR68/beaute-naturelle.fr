var class_images__manager =
[
    [ "accept", "class_images__manager.html#abcbe84aec4b95e9a04f83565467bf409", null ],
    [ "copy", "class_images__manager.html#a07b5e6baa2b5706d945ed0c1d28b2302", null ],
    [ "delete", "class_images__manager.html#a2f8258add505482d7f00ea26493a5723", null ],
    [ "findAll", "class_images__manager.html#a0f743f75b8f69be9a0ad3e6f4b5d3eb0", null ],
    [ "findOne", "class_images__manager.html#aba16c31123508b087d457165c732abff", null ],
    [ "getModerate", "class_images__manager.html#a6d3a6a148bf0c8752548e7e7ab149abb", null ],
    [ "need_moderate", "class_images__manager.html#aa85567bab816d0c34390dc49d41fc237", null ],
    [ "new", "class_images__manager.html#a3323ccf6ae1a31274a65d92c6457e745", null ],
    [ "update", "class_images__manager.html#abe62d28c10800e8e62701357e5e1e84a", null ]
];