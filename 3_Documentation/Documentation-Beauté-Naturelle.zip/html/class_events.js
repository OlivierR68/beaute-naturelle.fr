var class_events =
[
    [ "__construct", "class_events.html#a095c5d389db211932136b53f25f39685", null ],
    [ "accept_user", "class_events.html#af0f24e29a9d70ed2dfdf9921154814df", null ],
    [ "addEdit", "class_events.html#a62bfa4327c16425edb469078780f32e0", null ],
    [ "copy", "class_events.html#a07b5e6baa2b5706d945ed0c1d28b2302", null ],
    [ "delete", "class_events.html#a2f8258add505482d7f00ea26493a5723", null ],
    [ "ev", "class_events.html#a5feef34fe27d68b9c3fecb5a141e73a0", null ],
    [ "index", "class_events.html#a149eb92716c1084a935e04a8d95f7347", null ],
    [ "ListPage", "class_events.html#ad194e803e2214134564c336e093f9a8a", null ],
    [ "refuse_user", "class_events.html#aa96200d9ffeb698bd0e359d70909278d", null ],
    [ "register", "class_events.html#aaa492649fac3a0cbcb634b5024c1325d", null ],
    [ "unregister", "class_events.html#a28032439720eaffe48a52a07dc0dee2f", null ]
];