var class_smarty___internal___compile___block___parent =
[
    [ "$blockType", "class_smarty___internal___compile___block___parent.html#ae1418a10dd2f66c01179168a4a20f40e", null ],
    [ "$tag", "class_smarty___internal___compile___block___parent.html#a81d5015d41ed8ec66e9db8cdc5db9555", null ]
];