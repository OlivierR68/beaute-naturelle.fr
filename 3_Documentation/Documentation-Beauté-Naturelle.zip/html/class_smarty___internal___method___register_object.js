var class_smarty___internal___method___register_object =
[
    [ "registerObject", "class_smarty___internal___method___register_object.html#a2542009b888de828aa0e8785a91f9fca", null ],
    [ "$objMap", "class_smarty___internal___method___register_object.html#a2f9398fcdf56084f384c57481687f788", null ]
];