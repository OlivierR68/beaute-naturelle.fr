var class_smarty___internal___method___set_debug_template =
[
    [ "setDebugTemplate", "class_smarty___internal___method___set_debug_template.html#adc7f5b4f63275ca4c21738d2b20e7b58", null ],
    [ "$objMap", "class_smarty___internal___method___set_debug_template.html#a2f9398fcdf56084f384c57481687f788", null ]
];