var block_8textformat_8php =
[
    [ "smarty_block_textformat", "block_8textformat_8php.html#add31d546ba41e29253dd67f67503823d", null ]
];