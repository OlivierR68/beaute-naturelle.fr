var class_category__class =
[
    [ "__construct", "class_category__class.html#a095c5d389db211932136b53f25f39685", null ],
    [ "getArray", "class_category__class.html#a1ccf58e5634271a15f24d95d191868b6", null ],
    [ "getDescription", "class_category__class.html#a2e7bb35c71bf1824456ceb944cb7a845", null ],
    [ "getHeader", "class_category__class.html#a614834f1605e407376028e8c82298c82", null ],
    [ "getHeaderUrl", "class_category__class.html#ad5841043bb731dd3dbfe0b98365e67d7", null ],
    [ "getId", "class_category__class.html#a12251d0c022e9e21c137a105ff683f13", null ],
    [ "getImg", "class_category__class.html#a2bfa9d0fe5b14b3d25ee0323edb57b7c", null ],
    [ "getImgUrl", "class_category__class.html#ac9ecc6de4906c5fb10358a2cf7617583", null ],
    [ "getSlug", "class_category__class.html#aba91cb698fc762d9fc0975c9f73ae9c4", null ],
    [ "getTitle", "class_category__class.html#a95e859a4588a39a1824b717378a84c29", null ],
    [ "getUrl", "class_category__class.html#accd14bda49a1044b4d8dd93f020f11ee", null ],
    [ "getVisible", "class_category__class.html#afd9abdc6ad9261029511c06c651571a3", null ],
    [ "hydrate", "class_category__class.html#abf23c53dd5e53d3c72d8759d6eb36f4c", null ],
    [ "setDescription", "class_category__class.html#ade46ca92dc0b1cd1795bad78cf6dad07", null ],
    [ "setHeader", "class_category__class.html#a4f50119ae2a3f64364d75850a22a8f49", null ],
    [ "setId", "class_category__class.html#a87313ad678fb2a2a8efb435cf0bdb9a0", null ],
    [ "setImg", "class_category__class.html#a1a92ea5804b7f32e4b002cd7f2dd857e", null ],
    [ "setSlug", "class_category__class.html#ada3500fb6b31062a29d0f9ff1985e1c0", null ],
    [ "setTitle", "class_category__class.html#a884ba9bb0d54bde7839e798db7964476", null ],
    [ "setVisible", "class_category__class.html#a9cf191c4cc0675c18cfa17bda3f8db75", null ]
];