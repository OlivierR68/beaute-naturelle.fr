var class_smarty___internal___method___unregister_cache_resource =
[
    [ "unregisterCacheResource", "class_smarty___internal___method___unregister_cache_resource.html#aaf74a8650e4b77e697a1f21fcc19b240", null ],
    [ "$objMap", "class_smarty___internal___method___unregister_cache_resource.html#a2f9398fcdf56084f384c57481687f788", null ]
];