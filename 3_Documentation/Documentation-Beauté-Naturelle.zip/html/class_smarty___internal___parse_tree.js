var class_smarty___internal___parse_tree =
[
    [ "__destruct", "class_smarty___internal___parse_tree.html#a421831a265621325e1fdd19aace0c758", null ],
    [ "to_smarty_php", "class_smarty___internal___parse_tree.html#a99bcdd9ff4b9c7729ae3a63aa3d4cd31", null ],
    [ "$data", "class_smarty___internal___parse_tree.html#a6efc15b5a2314dd4b5aaa556a375c6d6", null ],
    [ "$subtrees", "class_smarty___internal___parse_tree.html#a57499dece2183f4658f0af70515a965c", null ]
];