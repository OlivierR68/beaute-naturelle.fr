var class_smarty___internal___method___assign_global =
[
    [ "assignGlobal", "class_smarty___internal___method___assign_global.html#a862ba932e5991955668fca38ea1de159", null ],
    [ "$objMap", "class_smarty___internal___method___assign_global.html#a2f9398fcdf56084f384c57481687f788", null ]
];