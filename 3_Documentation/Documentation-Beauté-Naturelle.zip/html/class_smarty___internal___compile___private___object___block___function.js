var class_smarty___internal___compile___private___object___block___function =
[
    [ "setup", "class_smarty___internal___compile___private___object___block___function.html#a1a1e6e016c7f1aff169080120b21afd6", null ]
];