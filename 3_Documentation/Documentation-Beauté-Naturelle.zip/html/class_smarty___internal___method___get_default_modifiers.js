var class_smarty___internal___method___get_default_modifiers =
[
    [ "getDefaultModifiers", "class_smarty___internal___method___get_default_modifiers.html#ac5b49c2a3525dfc1d95aac37e42c8412", null ],
    [ "$objMap", "class_smarty___internal___method___get_default_modifiers.html#a2f9398fcdf56084f384c57481687f788", null ]
];