var class_smarty___internal___compile___private___registered___block =
[
    [ "setup", "class_smarty___internal___compile___private___registered___block.html#a1f8a752ddc27c96cc06ce6abd5a8c07a", null ]
];