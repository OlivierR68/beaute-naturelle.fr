var class_smarty___internal___method___register_plugin =
[
    [ "registerPlugin", "class_smarty___internal___method___register_plugin.html#aa594996e01ef49eb7140adfedaa41a67", null ],
    [ "$objMap", "class_smarty___internal___method___register_plugin.html#a2f9398fcdf56084f384c57481687f788", null ]
];