var class_smarty___internal___method___load_plugin =
[
    [ "loadPlugin", "class_smarty___internal___method___load_plugin.html#ad96e7b76e3b2a61f3c6a8c3ea25f4f36", null ],
    [ "$plugin_files", "class_smarty___internal___method___load_plugin.html#a72123b4af9b47a2acba12e35dd049797", null ]
];