var class_smarty___internal___method___register_cache_resource =
[
    [ "registerCacheResource", "class_smarty___internal___method___register_cache_resource.html#a27f9d5963aa6dd921c36088fa5f952d9", null ],
    [ "$objMap", "class_smarty___internal___method___register_cache_resource.html#a2f9398fcdf56084f384c57481687f788", null ]
];