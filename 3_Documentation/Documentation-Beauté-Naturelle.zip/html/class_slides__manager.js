var class_slides__manager =
[
    [ "copy", "class_slides__manager.html#a07b5e6baa2b5706d945ed0c1d28b2302", null ],
    [ "delete", "class_slides__manager.html#a2f8258add505482d7f00ea26493a5723", null ],
    [ "findAll", "class_slides__manager.html#a0f743f75b8f69be9a0ad3e6f4b5d3eb0", null ],
    [ "findOne", "class_slides__manager.html#aba16c31123508b087d457165c732abff", null ],
    [ "new", "class_slides__manager.html#a3323ccf6ae1a31274a65d92c6457e745", null ],
    [ "orderDown", "class_slides__manager.html#ad6c776228db714a33ab1711fc99273c4", null ],
    [ "orderUp", "class_slides__manager.html#abc9f2822b3e799b899c3e137245d82dc", null ],
    [ "toggleVisible", "class_slides__manager.html#ad77a546e0eca0e8926aedfcded15ebfe", null ],
    [ "update", "class_slides__manager.html#abe62d28c10800e8e62701357e5e1e84a", null ]
];