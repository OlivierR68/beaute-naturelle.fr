var class_smarty___internal___method___register_class =
[
    [ "registerClass", "class_smarty___internal___method___register_class.html#a17dbf90a3e94fa04bc25387e672047a6", null ],
    [ "$objMap", "class_smarty___internal___method___register_class.html#a2f9398fcdf56084f384c57481687f788", null ]
];