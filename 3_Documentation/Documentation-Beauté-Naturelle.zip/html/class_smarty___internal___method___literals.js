var class_smarty___internal___method___literals =
[
    [ "addLiterals", "class_smarty___internal___method___literals.html#af554a649f48ced16fc40c684e2bdbe89", null ],
    [ "getLiterals", "class_smarty___internal___method___literals.html#a12dbc2b7eab5a2d6481fc0b3a4a5c53c", null ],
    [ "setLiterals", "class_smarty___internal___method___literals.html#ad7f73f0dd0875a2348cd66c342ac0a91", null ],
    [ "$objMap", "class_smarty___internal___method___literals.html#a2f9398fcdf56084f384c57481687f788", null ]
];