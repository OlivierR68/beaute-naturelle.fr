var class_newsletter =
[
    [ "__construct", "class_newsletter.html#a095c5d389db211932136b53f25f39685", null ],
    [ "delete", "class_newsletter.html#a2f8258add505482d7f00ea26493a5723", null ],
    [ "export_csv", "class_newsletter.html#a212c9d3feacc3af13a5350fbcd48cdb3", null ],
    [ "index", "class_newsletter.html#a149eb92716c1084a935e04a8d95f7347", null ],
    [ "isInBase", "class_newsletter.html#a37773008a31ed0c2f8b3eca917505eec", null ],
    [ "subscribe", "class_newsletter.html#ab4c9a84acdb17655eebea895b9dcc311", null ]
];