var class_smarty___cache_resource___apc =
[
    [ "__construct", "class_smarty___cache_resource___apc.html#a095c5d389db211932136b53f25f39685", null ],
    [ "delete", "class_smarty___cache_resource___apc.html#a9959a1c2ba36e72aee7f974df28b60d1", null ],
    [ "purge", "class_smarty___cache_resource___apc.html#ac400be513972a68ea08ef845d5b16824", null ],
    [ "read", "class_smarty___cache_resource___apc.html#a22b42d6b1291b3a59c1e457c0d4727a5", null ],
    [ "write", "class_smarty___cache_resource___apc.html#a914ddd5bfb233d53b6413ec9d51dcd99", null ]
];