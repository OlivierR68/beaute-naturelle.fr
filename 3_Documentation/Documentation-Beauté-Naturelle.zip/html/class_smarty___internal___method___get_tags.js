var class_smarty___internal___method___get_tags =
[
    [ "getTags", "class_smarty___internal___method___get_tags.html#a012c17dc3ec53772dfeb1ef346875733", null ],
    [ "$objMap", "class_smarty___internal___method___get_tags.html#a2f9398fcdf56084f384c57481687f788", null ]
];