var class_smarty___internal___method___add_default_modifiers =
[
    [ "addDefaultModifiers", "class_smarty___internal___method___add_default_modifiers.html#a120306471bc44b4ec9b88ee4b3e81c13", null ],
    [ "$objMap", "class_smarty___internal___method___add_default_modifiers.html#a2f9398fcdf56084f384c57481687f788", null ]
];