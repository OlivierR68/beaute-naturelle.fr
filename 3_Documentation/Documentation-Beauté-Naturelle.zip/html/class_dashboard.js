var class_dashboard =
[
    [ "__construct", "class_dashboard.html#a095c5d389db211932136b53f25f39685", null ],
    [ "index", "class_dashboard.html#a149eb92716c1084a935e04a8d95f7347", null ]
];