var class_smarty___internal___method___register_default_template_handler =
[
    [ "registerDefaultTemplateHandler", "class_smarty___internal___method___register_default_template_handler.html#a753f9034a0f3705a7e50d5c8abec3101", null ],
    [ "$objMap", "class_smarty___internal___method___register_default_template_handler.html#a2f9398fcdf56084f384c57481687f788", null ]
];