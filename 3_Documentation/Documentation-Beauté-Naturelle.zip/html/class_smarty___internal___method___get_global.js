var class_smarty___internal___method___get_global =
[
    [ "getGlobal", "class_smarty___internal___method___get_global.html#a8cca1d92825b2c350f2ebb44f23cb835", null ],
    [ "$objMap", "class_smarty___internal___method___get_global.html#a2f9398fcdf56084f384c57481687f788", null ]
];