var class_smarty___internal___method___set_default_modifiers =
[
    [ "setDefaultModifiers", "class_smarty___internal___method___set_default_modifiers.html#afb34be9eafc0647e45d8b7ec08149683", null ],
    [ "$objMap", "class_smarty___internal___method___set_default_modifiers.html#a2f9398fcdf56084f384c57481687f788", null ]
];