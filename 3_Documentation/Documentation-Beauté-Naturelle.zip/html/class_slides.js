var class_slides =
[
    [ "__construct", "class_slides.html#a095c5d389db211932136b53f25f39685", null ],
    [ "addEdit", "class_slides.html#a62bfa4327c16425edb469078780f32e0", null ],
    [ "copy", "class_slides.html#a07b5e6baa2b5706d945ed0c1d28b2302", null ],
    [ "delete", "class_slides.html#a2f8258add505482d7f00ea26493a5723", null ],
    [ "home", "class_slides.html#a174b8e4c7d4d7363c6f773671defdeff", null ],
    [ "ListPage", "class_slides.html#ad194e803e2214134564c336e093f9a8a", null ],
    [ "orderDown", "class_slides.html#ad6c776228db714a33ab1711fc99273c4", null ],
    [ "orderUp", "class_slides.html#abc9f2822b3e799b899c3e137245d82dc", null ],
    [ "visible", "class_slides.html#aefeb14340954f858c056054010fe5f4c", null ]
];