var class_admin_bar =
[
    [ "__construct", "class_admin_bar.html#a095c5d389db211932136b53f25f39685", null ]
];