var class_smarty___data =
[
    [ "__construct", "class_smarty___data.html#a79787f497166f7f5c02c5204d7eec283", null ],
    [ "$dataObjectName", "class_smarty___data.html#a0019ca94f3dcf5872150dbf81c9f8c4d", null ],
    [ "$smarty", "class_smarty___data.html#ac3ae29e9ccbb2006fa26fd9eb2c12117", null ]
];