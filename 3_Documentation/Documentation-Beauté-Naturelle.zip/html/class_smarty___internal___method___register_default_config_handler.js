var class_smarty___internal___method___register_default_config_handler =
[
    [ "registerDefaultConfigHandler", "class_smarty___internal___method___register_default_config_handler.html#af9b5bc7978f2d4501c799c805cb27a5a", null ],
    [ "$objMap", "class_smarty___internal___method___register_default_config_handler.html#a2f9398fcdf56084f384c57481687f788", null ]
];