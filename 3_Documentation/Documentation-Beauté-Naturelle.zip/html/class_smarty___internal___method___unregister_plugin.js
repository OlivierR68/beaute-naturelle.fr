var class_smarty___internal___method___unregister_plugin =
[
    [ "unregisterPlugin", "class_smarty___internal___method___unregister_plugin.html#a5405e2dd97c9b63c48ddab242782c0e8", null ],
    [ "$objMap", "class_smarty___internal___method___unregister_plugin.html#a2f9398fcdf56084f384c57481687f788", null ]
];