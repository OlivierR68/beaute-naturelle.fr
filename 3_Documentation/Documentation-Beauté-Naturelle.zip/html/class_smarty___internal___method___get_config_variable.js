var class_smarty___internal___method___get_config_variable =
[
    [ "getConfigVariable", "class_smarty___internal___method___get_config_variable.html#aa8fe06fa68766121b45b3369fc7da3a1", null ],
    [ "$objMap", "class_smarty___internal___method___get_config_variable.html#a2f9398fcdf56084f384c57481687f788", null ]
];