var class_prestations =
[
    [ "__construct", "class_prestations.html#a095c5d389db211932136b53f25f39685", null ],
    [ "addEdit", "class_prestations.html#a62bfa4327c16425edb469078780f32e0", null ],
    [ "addEdit_cat", "class_prestations.html#a9105a8c11ca21ec61642bcde7ab85b1f", null ],
    [ "addEdit_subcat", "class_prestations.html#a5a3b6307c1ca285f31d11a727f7abf84", null ],
    [ "cat", "class_prestations.html#a7ad1e1d45aad5fe0142373df4c23c1cd", null ],
    [ "copy_presta", "class_prestations.html#a504f39a7bd058f0765f79f706080b0e2", null ],
    [ "delete", "class_prestations.html#a2f8258add505482d7f00ea26493a5723", null ],
    [ "delete_cat", "class_prestations.html#a261bdb5d536b43aa2c3816eb593515ce", null ],
    [ "delete_subcat", "class_prestations.html#af2ba290ed1bb351eac36be8135124ce3", null ],
    [ "index", "class_prestations.html#a149eb92716c1084a935e04a8d95f7347", null ],
    [ "ListPage", "class_prestations.html#ad194e803e2214134564c336e093f9a8a", null ],
    [ "ListPage_cat", "class_prestations.html#acaf505bbf465728c49b49c41c1302062", null ],
    [ "orderDown", "class_prestations.html#ad6c776228db714a33ab1711fc99273c4", null ],
    [ "orderUp", "class_prestations.html#abc9f2822b3e799b899c3e137245d82dc", null ],
    [ "visible_cat", "class_prestations.html#a1cb86da56bfc9388da62ae975d7d3e52", null ],
    [ "visible_presta", "class_prestations.html#a7f677ca79c6431118e3a8a34aebda820", null ],
    [ "visible_subcat", "class_prestations.html#a0f7a6a767916f0084fe083e01c390a6d", null ]
];