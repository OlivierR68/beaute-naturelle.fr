var class_smarty___internal___method___unregister_resource =
[
    [ "unregisterResource", "class_smarty___internal___method___unregister_resource.html#ad6c11357c54f372383a69f210cdd99c7", null ],
    [ "$objMap", "class_smarty___internal___method___unregister_resource.html#a2f9398fcdf56084f384c57481687f788", null ]
];