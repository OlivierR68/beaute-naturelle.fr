var class_smarty___internal___method___clear_config =
[
    [ "clearConfig", "class_smarty___internal___method___clear_config.html#a88066a1c57cd01835b7945a753c6eae4", null ],
    [ "$objMap", "class_smarty___internal___method___clear_config.html#a2f9398fcdf56084f384c57481687f788", null ]
];