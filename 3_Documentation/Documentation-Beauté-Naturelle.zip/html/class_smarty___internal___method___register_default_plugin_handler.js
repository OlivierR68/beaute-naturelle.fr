var class_smarty___internal___method___register_default_plugin_handler =
[
    [ "registerDefaultPluginHandler", "class_smarty___internal___method___register_default_plugin_handler.html#ac565bc37acecd582d56a0eb06d496564", null ],
    [ "$objMap", "class_smarty___internal___method___register_default_plugin_handler.html#a2f9398fcdf56084f384c57481687f788", null ]
];