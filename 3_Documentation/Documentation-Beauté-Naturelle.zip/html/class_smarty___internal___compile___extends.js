var class_smarty___internal___compile___extends =
[
    [ "compile", "class_smarty___internal___compile___extends.html#a5d6497cd65043e9b1b300c548247e5ff", null ],
    [ "$optional_attributes", "class_smarty___internal___compile___extends.html#a899d1eb4a6fecbd6ce696adb171c80a4", null ],
    [ "$required_attributes", "class_smarty___internal___compile___extends.html#ae799507d5461de485f3a618abeecea95", null ],
    [ "$shorttag_order", "class_smarty___internal___compile___extends.html#a2ccb25269c3a92e8c4796c7ef23725e6", null ]
];