var class_smarty___internal___method___get_config_vars =
[
    [ "getConfigVars", "class_smarty___internal___method___get_config_vars.html#affdecdcb064815fa7ce313696ddf2c72", null ],
    [ "$objMap", "class_smarty___internal___method___get_config_vars.html#a2f9398fcdf56084f384c57481687f788", null ]
];