var class_smarty___internal___method___clear_cache =
[
    [ "clearCache", "class_smarty___internal___method___clear_cache.html#a04ca4fa17b5f0c66465c3cfd30e647cc", null ],
    [ "$objMap", "class_smarty___internal___method___clear_cache.html#a2f9398fcdf56084f384c57481687f788", null ]
];