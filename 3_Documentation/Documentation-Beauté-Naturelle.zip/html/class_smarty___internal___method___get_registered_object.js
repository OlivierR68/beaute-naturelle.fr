var class_smarty___internal___method___get_registered_object =
[
    [ "getRegisteredObject", "class_smarty___internal___method___get_registered_object.html#aefb5fe58d730025f2fe29ff35c6f27e1", null ],
    [ "$objMap", "class_smarty___internal___method___get_registered_object.html#a2f9398fcdf56084f384c57481687f788", null ]
];