var class_smarty___internal___method___unregister_object =
[
    [ "unregisterObject", "class_smarty___internal___method___unregister_object.html#a37d8e1e536f940debdaa029081e28e08", null ],
    [ "$objMap", "class_smarty___internal___method___unregister_object.html#a2f9398fcdf56084f384c57481687f788", null ]
];