var class_smarty___internal___method___register_resource =
[
    [ "registerResource", "class_smarty___internal___method___register_resource.html#ae8a102612caa4f52e6235eaca9d48096", null ],
    [ "$objMap", "class_smarty___internal___method___register_resource.html#a2f9398fcdf56084f384c57481687f788", null ]
];