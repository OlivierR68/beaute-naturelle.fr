var class_smarty___internal___resource___extends =
[
    [ "checkTimestamps", "class_smarty___internal___resource___extends.html#a6de5f37a8f755b87becf29ed067a982b", null ],
    [ "getBasename", "class_smarty___internal___resource___extends.html#a91cdf7da12bdc51906539506dd26159b", null ],
    [ "getContent", "class_smarty___internal___resource___extends.html#a0e40116a3d4f59cf7ea39f83441169b8", null ],
    [ "populate", "class_smarty___internal___resource___extends.html#a07a771f460d625d63fcb72d0aeed0b01", null ],
    [ "populateTimestamp", "class_smarty___internal___resource___extends.html#a0935298de0f84d80fdb2ec7c9c52a763", null ],
    [ "$mbstring_overload", "class_smarty___internal___resource___extends.html#a2d2e9633d7a8387cb8072457e11839b5", null ]
];