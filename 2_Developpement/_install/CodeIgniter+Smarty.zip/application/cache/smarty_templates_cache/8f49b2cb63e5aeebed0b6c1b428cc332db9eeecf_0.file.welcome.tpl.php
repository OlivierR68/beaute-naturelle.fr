<?php
/* Smarty version 3.1.34-dev-7, created on 2020-01-31 17:25:42
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\welcome.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e34631662beb6_22485021',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8f49b2cb63e5aeebed0b6c1b428cc332db9eeecf' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\welcome.tpl',
      1 => 1580491382,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e34631662beb6_22485021 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<header><title>This is title</title></header>
<body>
<?php echo $_smarty_tpl->tpl_vars['message']->value;?>

</body>
</html><?php }
}
