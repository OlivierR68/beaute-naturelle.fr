<?php
/* Smarty version 3.1.34-dev-7, created on 2020-01-31 17:35:09
  from 'C:\Users\PC-Olivier\Documents\GitHub\beaute-naturelle.fr\2_Developpement\_smarty\application\views\home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e34654d4ac884_66172919',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4d28a351f3b104d80e41ed9ca16dba8fdcadc4e6' => 
    array (
      0 => 'C:\\Users\\PC-Olivier\\Documents\\GitHub\\beaute-naturelle.fr\\2_Developpement\\_smarty\\application\\views\\home.tpl',
      1 => 1580491917,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e34654d4ac884_66172919 (Smarty_Internal_Template $_smarty_tpl) {
?><p>j'aimes les frites</p><?php }
}
